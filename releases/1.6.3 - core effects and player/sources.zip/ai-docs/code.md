# ai-notes: code

<!-- AI-only notes. Owner: principal-engineer. Dense format OK. Find a paragraph: grep -n on the index, then sed -n 'A,Bp'. -->

## Sub-documents (ai-docs, same owner)
- ai-docs/code-history.md § ai-notes: code — history (per-version notes, newest first) — L1-4 (4 lines)
- ai-docs/code-history.md § 1.6.2 notes (splash for both programs) — L5-9 (5 lines)
- ai-docs/code-history.md § State (1.6.1) — L10-17 (8 lines)
- ai-docs/code-history.md § State (1.6.0) — L18-20 (3 lines)
- ai-docs/code-history.md § 1.6.0 notes — L21-34 (14 lines)
- ai-docs/code-history.md § State (1.5.0) — L35-37 (3 lines)
- ai-docs/code-history.md § 1.5.0 notes — L38-47 (10 lines)
- ai-docs/code-history.md § State (1.4.0) — L48-50 (3 lines)
- ai-docs/code-history.md § 1.4.0 notes — L51-55 (5 lines)
- ai-docs/code-history.md § State (1.3.0) — L56-58 (3 lines)
- ai-docs/code-history.md § 1.3.0 notes (plan: architecture-plan-1.3.0.md, steps M0-M12) — L59-74 (16 lines)
- ai-docs/code-history.md § State (1.2.6 target) — L75-77 (3 lines)
- ai-docs/code-history.md § 1.2.6 notes (REQ-096..105; plan ADR-059..065) — L78-89 (12 lines)
- ai-docs/code-history.md § State (1.2.0) — L90-95 (6 lines)
- ai-docs/code-history.md § 1.2.0 notes — L96-111 (16 lines)
- ai-docs/code-history.md § 1.1.0 notes (UI restructuring) — L112-124 (13 lines)
- ai-docs/code-history.md § 0.4.0 notes — L125-138 (14 lines)
- ai-docs/code-history.md § 0.3.0 notes — L139-148 (10 lines)
- ai-docs/code-history.md § Packaging / CI — L149-153 (5 lines)
- ai-docs/code-modules.md § ai-notes: code — module facts (dense, per module) — L1-4 (4 lines)
- ai-docs/code-modules.md § Module facts — L5-41 (37 lines)
- ai-docs/code-req-tests.md § ai-notes: code — requirement -> test files (generated) — L1-83 (83 lines)

## Index of docs/code*.md
- docs/code-360.md § Code — boxes, text size and 360° video (1.2.6) — L1-5 (5 lines)
- docs/code-360.md § Where things are — L6-20 (15 lines)
- docs/code-360.md § How the camera reaches ffmpeg — L21-38 (18 lines)
- docs/code-360.md § Spike results (milestone 0, measured with ffmpeg 6.1.1) — L39-56 (18 lines)
- docs/code-360.md § Settled points — L57-75 (19 lines)
- docs/code-360.md § Boxes, size and commands — L76-89 (14 lines)
- docs/code-360.md § Tests and fixtures — L90-99 (10 lines)
- docs/code-360.md § Known limits — L100-106 (7 lines)
- docs/code-architecture.md § Code — module architecture — L1-8 (8 lines)
- docs/code-architecture.md § Layers — L9-24 (16 lines)
- docs/code-architecture.md § Module dependency graph — L25-61 (37 lines)
- docs/code-architecture.md § Cycles — L62-82 (21 lines)
- docs/code-architecture.md § Import → timeline → preview → export — L83-115 (33 lines)
- docs/code-architecture.md § Threads and channels — L116-143 (28 lines)
- docs/code-architecture.md § videolore player — L144-162 (19 lines)
- docs/code-architecture.md § Dependencies of each module — L163-202 (40 lines)
- docs/code-effects.md § Code — effects on clips, the video's own subtitles, positions, SRT (1.2.0) — L1-4 (4 lines)
- docs/code-effects.md § Applying an effect — L5-27 (23 lines)
- docs/code-effects.md § Fades at the video's edges — L28-41 (14 lines)
- docs/code-effects.md § Whole-video effects are copies on the clips (1.6.1, REQ-147, REQ-148) — L42-55 (14 lines)
- docs/code-effects.md § Clip volume — L56-65 (10 lines)
- docs/code-effects.md § Subtitles for a clip or the whole video — L66-87 (22 lines)
- docs/code-effects.md § Reading a track — L88-95 (8 lines)
- docs/code-effects.md § Matching words (`align`) — L96-114 (19 lines)
- docs/code-effects.md § Subtitle positions — L115-136 (22 lines)
- docs/code-effects.md § SRT export — L137-143 (7 lines)
- docs/code-effects.md § Timeline ruler — L144-150 (7 lines)
- docs/code-effects.md § Project format 3 — L151-160 (10 lines)
- docs/code-effects.md § Project format 9 (1.6.1, REQ-149) — L161-174 (14 lines)
- docs/code-export.md § Code — Export dialog, Clean audio and text boxes (1.4.0) — L1-6 (6 lines)
- docs/code-export.md § Where things are — L7-17 (11 lines)
- docs/code-export.md § Export dialog — L18-35 (18 lines)
- docs/code-export.md § Formats — L36-48 (13 lines)
- docs/code-export.md § Clean audio — L49-64 (16 lines)
- docs/code-export.md § Text boxes (REQ-111, 115, 116, 117) — L65-84 (20 lines)
- docs/code-export.md § Project format 6 — L85-95 (11 lines)
- docs/code-export.md § Tests — L96-105 (10 lines)
- docs/code-export.md § Known limits — L106-111 (6 lines)
- docs/code-frame.md § Code — Change aspect, Scale, Move and keyframes (1.5.0) — L1-5 (5 lines)
- docs/code-frame.md § Where things are — L6-19 (14 lines)
- docs/code-frame.md § Storage and time (REQ-132) — L20-35 (16 lines)
- docs/code-frame.md § The picture (REQ-125, 126, 131) — L36-63 (28 lines)
- docs/code-frame.md § Interface (REQ-124, 127..130) — L64-80 (17 lines)
- docs/code-frame.md § Tests — L81-88 (8 lines)
- docs/code-frame.md § Known limits — L89-96 (8 lines)
- docs/code-hardware-qg05.md § Code — hardware export: real-hardware verification (QG-05) — L1-5 (5 lines)
- docs/code-hardware-qg05.md § Checklist — L6-30 (25 lines)
- docs/code-hardware-qg05.md § Results — L31-57 (27 lines)
- docs/code-hardware.md § Code — hardware export ("Export: Faster") — L1-7 (7 lines)
- docs/code-hardware.md § Modules — L8-19 (12 lines)
- docs/code-hardware.md § Methods and arguments — L20-53 (34 lines)
- docs/code-hardware.md § The hardware check (probe) — L54-97 (44 lines)
- docs/code-hardware.md § The export — L98-120 (23 lines)
- docs/code-hardware.md § Failure memory — L121-132 (12 lines)
- docs/code-hardware.md § Tests — L133-166 (34 lines)
- docs/code-hardware.md § Real-hardware verification — L167-171 (5 lines)
- docs/code-hardware.md § Known limitations — L172-189 (18 lines)
- docs/code-index.md § Code — index — L1-8 (8 lines)
- docs/code-index.md § Programs and start-up — L9-20 (12 lines)
- docs/code-index.md § Application core — L21-30 (10 lines)
- docs/code-index.md § Media and project model — L31-39 (9 lines)
- docs/code-index.md § Effects — L40-48 (9 lines)
- docs/code-index.md § Subtitles and texts — L49-59 (11 lines)
- docs/code-index.md § 360° video — L60-65 (6 lines)
- docs/code-index.md § Preview — L66-71 (6 lines)
- docs/code-index.md § Export — L72-79 (8 lines)
- docs/code-index.md § Hardware export — L80-85 (6 lines)
- docs/code-index.md § Interface — L86-93 (8 lines)
- docs/code-index.md § videolore player — L94-102 (9 lines)
- docs/code-index.md § Packaging and build — L103-108 (6 lines)
- docs/code-index.md § Integration tests (real ffmpeg) — L109-112 (4 lines)
- docs/code-lut.md § Code — Apply LUT (1.6.0) — L1-4 (4 lines)
- docs/code-lut.md § Where things are — L5-18 (14 lines)
- docs/code-lut.md § The LUT file — L19-29 (11 lines)
- docs/code-lut.md § In the filter graph (ADR-110) — L30-49 (20 lines)
- docs/code-lut.md § Missing or changed file (REQ-136) — L50-59 (10 lines)
- docs/code-lut.md § Undo and project format 8 — L60-68 (9 lines)
- docs/code-lut.md § Verification of `lut3d` — L69-76 (8 lines)
- docs/code-lut.md § Tests — L77-84 (8 lines)
- docs/code-lut.md § Known limits — L85-88 (4 lines)
- docs/code-modules.md § Code — modules and patterns — L1-6 (6 lines)
- docs/code-modules.md § Module map — L7-46 (40 lines)
- docs/code-modules.md § Main patterns — L47-112 (66 lines)
- docs/code-modules.md § Conventions — L113-129 (17 lines)
- docs/code-modules.md § Machine, recommendation and "How hard videolore works" — L130-154 (25 lines)
- docs/code-packaging.md § Code — installers, notices and known limitations — L1-2 (2 lines)
- docs/code-packaging.md § Release assets — L3-18 (16 lines)
- docs/code-packaging.md § cargo-packager configuration (Windows and macOS) — L19-38 (20 lines)
- docs/code-packaging.md § Bundled ffmpeg — L39-53 (15 lines)
- docs/code-packaging.md § Notices — L54-64 (11 lines)
- docs/code-packaging.md § Desktop integration — L65-75 (11 lines)
- docs/code-packaging.md § Manual checklist per OS (before publishing a release) — L76-98 (23 lines)
- docs/code-packaging.md § Known limitations — L99-116 (18 lines)
- docs/code-player.md § Code — videolore player and the workspace (1.6.0, start screen 1.6.2) — L1-4 (4 lines)
- docs/code-player.md § Workspace — L5-20 (16 lines)
- docs/code-player.md § Modules of `player/src` — L21-32 (12 lines)
- docs/code-player.md § How it works (ADR-105..108, 118, 119) — L33-59 (27 lines)
- docs/code-player.md § Packaging (ADR-108, 115) — L60-69 (10 lines)
- docs/code-player.md § Known limits — L70-76 (7 lines)
- docs/code-player.md § Start screen (1.6.2, REQ-150) — L77-84 (8 lines)
- docs/code-splash-icons.md § Code — splash screen and icons (1.6.0, splash shared with the player in 1.6.2) — L1-4 (4 lines)
- docs/code-splash-icons.md § Splash — L5-37 (33 lines)
- docs/code-splash-icons.md § Icons — L38-75 (38 lines)
- docs/code-splash-icons.md § Tests — L76-82 (7 lines)
- docs/code-testing.md § Code — tests and CI — L1-2 (2 lines)
- docs/code-testing.md § Tests — L3-89 (87 lines)
- docs/code-testing.md § Coverage — L90-97 (8 lines)
- docs/code-testing.md § Continuous integration (`.github/workflows/build.yml`) — L98-109 (12 lines)
- docs/code-testing.md § Integration test files — L110-136 (27 lines)
- docs/code-testing.md § Other test notes — L137-153 (17 lines)
- docs/code-testing.md § Suite size and time — L154-160 (7 lines)
- docs/code-text.md § Code — text items, selection and 360° in 1.3.0 — L1-10 (10 lines)
- docs/code-text.md § Where things are — L11-23 (13 lines)
- docs/code-text.md § Model and file — L24-38 (15 lines)
- docs/code-text.md § Effects as ASS events — L39-53 (15 lines)
- docs/code-text.md § Texts fixed to the sphere — L54-77 (24 lines)
- docs/code-text.md § Export of a project with 360 clips — L78-94 (17 lines)
- docs/code-text.md § Selection and Context Menu — L95-105 (11 lines)
- docs/code-text.md § Tests — L106-115 (10 lines)
- docs/code-text.md § Known limits — L116-122 (7 lines)
- docs/code-ui.md § Code — the window (UI) — L1-8 (8 lines)
- docs/code-ui.md § Window structure — L9-23 (15 lines)
- docs/code-ui.md § Layout — L24-47 (24 lines)
- docs/code-ui.md § Actions, menus, shortcuts — L48-77 (30 lines)
- docs/code-ui.md § Floating windows and markers — L78-95 (18 lines)
- docs/code-ui.md § Undo names, recent projects, drag and drop — L96-107 (12 lines)
- docs/code-ui.md § Settings file — L108-114 (7 lines)
- docs/code-ui.md § Since 1.2.0 — L115-125 (11 lines)
- docs/code-ui.md § Preview picture (1.2.6) — L126-134 (9 lines)
- docs/code.md § Code — L1-30 (30 lines)
- docs/code.md § Build, test, run — L31-46 (16 lines)
- docs/code.md § System requirements for building — L47-56 (10 lines)
- docs/code.md § Settings and machine detection — L57-67 (11 lines)
- docs/code.md § CPU baseline for speech recognition — L68-77 (10 lines)
- docs/code.md § Cargo features — L78-88 (11 lines)
- docs/code.md § Finding ffmpeg — L89-96 (8 lines)
- docs/code.md § Dependencies — L97-122 (26 lines)

## State (1.6.3, release "core effects and player")
- RELEASE consolidation done: app.rs split (app/command.rs = Command + undo_name + ZOOM_STEP, re-exported from app; app/export_flow.rs = export_context, open_export_dialog, start_export_choice, run_export_choice, start_export, start_export_with, export_extension as pub(super)); redundant clones removed (subs_create clones only the ffmpeg path, preview launch moves cfg fields, player ui line drag moves ids); fonts::families_of gets an iterator + sort_by_cached_key.
- Tests: hw.rs `in_parallel` (std::thread::scope) for the vendor and damage loops; v13 "away" export 4 s -> 2 s; app/hw_tests repeat test limits 30/60 ms -> 200/400 ms (flaked under load: an answering fake was late). Integration suite is CPU-bound (~270 s user / 8 threads): wall time ~45-60 s depending on machine load; the slowest tests are 1080p camera views of 360 exports (~25 s each).
- Suite: 563 lib (+2 ignored), 62 integration (+3 ignored), 33 player, 3 player integration. Line cov 95.6% (workspace), feature 150/150.
- Libraries: cargo update (bytes, cc, pin-project*, pollster, regex*, smallvec, sysinfo 0.40.4, uuid, zeroize); manifest sysinfo 0.40.3 -> 0.40.4; every direct dep already at latest stable (crates.io 2026-11-20). cargo deny ok; notices regenerated (both files).

## Library estimates (1.6.3)
- egui_kittest (dev): would replace the hand-made accesskit Harness in ui/ux_tests.rs + player ui_tests. Same egui release train, MIT/Apache. Not now: our harness is small, works headless without wgpu, and kittest pulls a renderer for snapshots.
- ttf-parser: measured text fit (debt 1.4.0). Not now: RUSTSEC-2026-0192 unmaintained flag under cargo-deny (see history 1.6.0); egui's own galley measure is enough.
- nextest (tool, not a crate): per-test process isolation and timing. Not now: the suite is CPU-bound, not scheduling-bound; RUSTC_BOOTSTRAP=1 <test bin> -Z unstable-options --report-time gives per-test times.
- rayon: parallel outcheck sampling / tests. Not now: ffmpeg processes are already bounded by jobs::Scheduler; threads::scope suffices.

## Local env (dev box)
- This box: no libasound2-dev, no espeak-ng system-wide. Rebuild in the session scratchpad: env.sh (PKG_CONFIG_PATH alsa + LIBCLANG_PATH=/usr/lib/llvm-18/lib + VIDEOLORE_REQUIRE_FFMPEG=1) and run.sh (`systemd-run --user --scope -p MemoryMax=8G -p MemorySwapMax=0 timeout 2400 ...`): EVERY cargo run goes through run.sh (10 GB OOM in 1.6.1). Dev ffmpeg 6.1.1. Test binaries: target/debug/build/videolore/<hash>/out/ (custom target layout).
- Scratchpad of 0.4.0 session: env.sh (espeak/model/alsa/libclang vars), ff-linux/ (BtbN 9.0.2-39 bundled build), bench/ (vlbench crate; job.rs updated for 0.4 ExportJob; saves bench.vlproj), vlbench-0.3.0-noflash (0.3.0 baseline binary) / vlbench-0.4.0.
- libasound2-dev not installed: `apt-get download libasound2-dev` into scratchpad, `dpkg-deb -x`, fix symlink libasound.so -> /usr/lib/x86_64-linux-gnu/libasound.so.2, sed prefix in alsa.pc, PKG_CONFIG_PATH=<that>/usr/lib/x86_64-linux-gnu/pkgconfig. LIBCLANG_PATH=/usr/lib/llvm-18/lib for whisper-rs-sys bindgen. espeak-ng not installed system-wide: `apt-get download espeak-ng espeak-ng-data libespeak-ng1 libpcaudio0 libsonic0`, dpkg-deb -x into scratchpad, PATH+LD_LIBRARY_PATH(usr/lib/x86_64-linux-gnu)+ESPEAK_DATA_PATH(.../espeak-ng-data); model via pinned URL+sha (as build.yml) -> VIDEOLORE_STT_MODEL. Real whisper test passes locally (espeak 1.51 and 1.52, ffmpeg 6.1.1 and 9.0.2, ggml native/AVX2/SSE-only builds: text "Hello world, this is VD floor.", lang en).
- Cross-check mac/win code: `rustup target add aarch64-apple-darwin x86_64-pc-windows-msvc`; `cargo clippy --target <t> --no-default-features --all-targets -- -D warnings` works (no C deps without default feats). Both clean at 0.2.0.
- cargo-deny 0.20.2 + cargo-about 0.9.3 (`--features cli`) in ~/.cargo/bin.

## Deps (rustc 1.100; requirements pinned to latest release in Cargo.toml, alphabetical)
eframe 0.37.0 (no default feats: glow, default_fonts, wayland, x11). rfd 0.18 (xdg-portal). cpal 0.18.2 opt `audio`. serde/serde_json, thiserror 2, directories 6, tempfile 3, sha2 0.11.1 (normal dep now), sysinfo 0.40.4 (no default, "system"; System::new() returns Result in 0.40!), ureq 3.5.2 opt (no default, rustls), whisper-rs 0.16.0 opt. Features default=[audio,stt], stt=[dep:whisper-rs, dep:ureq].
macOS-only: objc2 0.6.5, objc2-foundation 0.3.2 (std, NSAppleEventDescriptor, NSAppleEventManager, NSNotification, NSObject, NSString, NSURL), winit 0.30.13 (no default; only for EventLoopBuilderExtMacOS::with_default_menu(false); eframe doesn't re-export winit).
No dev-dependencies. egui_kittest NOT used: headless `ctx.run_ui(RawInput,..)`.
deny.toml allow-list includes Ubuntu-font-1.0 (epaint_default_fonts) + OFL-1.1, CDLA-Permissive-2.0 (webpki-roots), GPL-3.0-only (us). about.toml same list + workarounds ring/rustls; about.hbs prints "videolore (this program)" instead of version (else notices freshness breaks on every bump). notices.sh runs `cargo about generate --locked --all-features --offline`. Regenerate rust-crates.txt after ANY Cargo.lock change.

## Gotchas
- Docs index above: regenerate with a small script: for every docs/code*.md heading (#..####, outside code fences) line range = heading line to the line before the next heading.
- Visibility: methods moved into an app/ child module need pub(super) (child-private otherwise); `use super::*` in children sees app's private imports.
- whisper portable build (Andrea's decision, 0.2.x): .cargo/config.toml [env] GGML_NATIVE=OFF + SSE42/AVX/AVX2/FMA/F16C/BMI2=ON explicitly (ggml sets INS_ENB OFF if GGML_NATIVE_DEFAULT OFF, i.e. CMAKE_CROSSCOMPILING or SOURCE_DATE_EPOCH -> would fall to SSE-only; explicit avoids that). Verified flags.make: -march=x86-64 -msse4.2 -mf16c -mfma -mbmi2 -mavx -mavx2. ARM (macOS): NATIVE OFF + no GGML_CPU_ARM_ARCH -> no -march, Apple clang default apple-m1 (NEON/dotprod/fp16); x86 vars ignored. MSVC: GGML_AVX2 -> /arch:AVX2 + defs. mac/win whisper build NOT verified locally (no SDK) -> CI build/package jobs. build.rs has no rerun-if-env-changed for GGML_*: after edits `cargo clean -p whisper-rs-sys` (+--release, rm target/llvm-cov-target) and bump rust-cache prefix-key (all 4 uses: v2-rust-ggml-portable). Test packaging::whisper_is_built_for_a_portable_cpu_baseline include_str!s config + build.yml.
- **whisper-rs 0.16.0 `set_abort_callback_safe` is UB** (root cause of CI 0.2.0/0.2.1 failure `GenericError(-6)`): it boxes `Box<dyn FnMut>` again, passes `*mut Box<dyn FnMut>` but trampoline::<F> casts to `*mut F`; with F = closure{Arc<AtomicBool>} it reads ArcInner.data at (inner box ptr + 16) = uninitialised tail of the 8-byte alloc's 32-byte chunk -> nonzero on a used heap -> whisper_encode_internal returns false at its final abort check -> whisper_full_with_state -6 (lang detect passed: its encode gets nullptr callback). Also leaked the closure each call. Fix: own `unsafe extern "C" fn abort_requested(*mut c_void)` reading `*const AtomicBool`, set via `set_cancel_flag(&mut FullParams<'f,'f>, &'f AtomicBool)` (unsafe set_abort_callback + _user_data). Deterministic repro: allocate/free thousands of 0xFF Vec<u8> (8..64B) right before `transcribe` -> old code fails 3/3, new passes (`abort_check_of_whisper_ignores_heap_garbage`, named to start first in the parallel run). MALLOC_PERTURB_/tcache_count=0 did NOT reproduce; grooming before stt::run did not either (too many allocs in between). Don't use whisper-rs *_safe callbacks without reading their trampoline. whisper-rs maps codes wrongly too (7/8 positive) -> `whisper_full_error(code)` (-1/-2 mel, -3 lang, -4 decoders, -5 audio_ctx, -6 encode/abort, -7 kv cache, -8/-9 decode).
- CI: test steps (check + msrv) `set -o pipefail; cargo test | tee $RUNNER_TEMP/cargo-test.txt || { scripts/test-annotations.sh ...; exit 1; }` -> `::error file=,line=,title=test X failed::` (max 9 + summary; esc % CR LF, props also : ,). Annotations public via check-runs API. Coverage step not wrapped.
- egui 0.37: App::ui(&mut self, ui, frame); CentralPanel::show(ui,..); Id::new deprecated -> Id::unique; run_ui; FullOutput w/ texture deltas panics on drop -> drop_without_applying_deltas(); viewport commands for tests: out.viewport_output[&ViewportId::ROOT].commands; close button = RawInput.viewports[ROOT].events=[ViewportEvent::Close].
- clippy 1.100: as_chunks; type_complexity in test structs -> type alias; field_reassign_with_default in tests.
- Coverage: if it drops after toolchain change, rm -rf target/llvm-cov-target.
- FakeRunner::holding_streams(): stdout blocks until kill (avoids end-of-playback race).
- lavfi sine amplitude = 1/8 full scale (~4096 peak s16): thresholds in audio tests.
- Paste inside a clip splits it.
- `system_runner_runs_and_kills` uses `rustc` from PATH.
- Integration tests share ONE process: own_rss() counts every parallel test (whisper ~170MB peak, measured up to +159MB in the memory test). REQ-039 test therefore re-execs current_exe on the #[ignore] helper `memory_peak_of_one_preview` (env VIDEOLORE_MEMORY_PROBE=file, prints VIDEOLORE_PEAK=n on the libtest line -> parse with split_once). Was a wrong guess for the 0.2.0 CI failure (real cause: abort-callback UB above) but a genuine flakiness fix; kept.

## Debt
- Player: no settings file, no remembered volume/window; proxies are silent; macOS/Windows untested; About shares the editor's third-party text.
- LUT: DOMAIN, strength, perf unmeasured; lut3d on ffmpeg 9.x unverified.
- 1.2: alignment accuracy gate (above). Text edit after a drag can push a box over the edge (no re-clamp); positioned lines overlapping in time overlap on screen; default-place boxes of simultaneous lines are computed at the same spot (libass stacks them) -> preview hit boxes approximate. app.rs still ~2900 lines. Selection highlight in preview only as outline.
- 1.1: Ctrl/Cmd+V only reaches us when the system clipboard has text (egui-winit emits no Paste event otherwise) — pre-existing. Popups all open near the centre (offset 24 px each) and can cover each other. Instance popup shows "no longer exists" instead of closing. app.rs ~2600 lines -> split candidates (popups/recent/drop).
- dialogs.rs untested glue (0%); macOS module not covered (compiled only on mac).
- Proxy cache: no eviction. STT chunk boundary artefacts. No per-OS code signing.
- RemoveMedia drops undo history when referenced (simple & safe; could prune instead).
- Debt: summary fit floor 7 px (a longer text fails the test); both summaries per release; real_app tests do not start ffmpeg-free (player real_app(None) test uses the real locate).
- Debt: whole-video popup shows first clip only; whole copies diverge silently; no note when a clip is added after a whole-video effect.
- Not done / not verifiable here: 1.5.0 refusing schema 8 (helper only); macOS/Windows packaging of the player (config-only checked on Linux); splash look on a real display (no display here); player on macOS/Windows.
- Debt 1.5.0: camera.rs not moved onto keyframes.rs; no hardware/outcheck test with a frame effect (settings carry the frame size, covered by plan tests only); blur strength fixed; blurred fill + Scale re-renders the whole still per drag step; whole-video keys do not follow trims; no easing; ux test harness cannot run the colour picker; popup key timeline click path (select/seek) not driven by a pointer test (KeyBar pure tests only).
- Debt 1.4.0: best fit is an estimate (0.6 em), measured fit = future (ttf-parser); clean audio fixed strength (quiet speech -2.5 dB, very quiet noise removed fully); golden argv fixtures for v4/v5 projects not added (v1..v3 + migration unit tests); preview CPU with clean audio not measured; audio-only/preset exports have no hardware path (audio) / use the normal hw rules (video); SRT choice in dialog calls ExportSrt (existing); live preview of a width drag shows only the ghost outline; dialog tests do not click the combo boxes (state tested through commands); Edit menu is long (scrolls on small windows).
- Debt 1.3.0: anchored lines drawn as plain text (no preset style); egui box measure uses bundled font; slide estimate; flat box drag of anchored text on flat clip does not move it; mixed selection group moves per kind; M0 baselines/M11 perf numbers not recorded (gates pass); a text hidden by blink keeps its box; Sphere360 + hardware check path (compare graph) untested for anchored files; fonts missing in libass fallback untested on CI; JSON of Anchor360 limits: size_cd 1..=17000, wrap_cd 1..=36000.
- Debt 1.2.6: moving-camera export speed (see spike); POVs shared by copies of one source; Align H of a None-position line is a no-op; resize box wraps may move the centre slightly (text wraps more when bigger); no keyboard camera control; docs/architecture-360.md still says h_fov+v_fov / half-frame-early (architect to update); BtbN 9.x v360 not re-measured (reset_rot semantics assumed same).
- Debt: weekly cargo-deny schedule NOT added; QEMU old-CPU CI step NOT done; preview keeps its own system-temp dir (now chmod 0700, tempfile does not do it) for subs.ass — not lock-registered (no partial files there, removed on drop).

- Module cycles (docs/code-architecture.md § Cycles): 16-module SCC; pairs project<->settings, stt<->media, stt<->scratch, scratch<->proxy, lut<->project, subtitles<->timeline, subtitles<->text, text<->ass. Idea: a base module of shared helpers (capped read/atomic write, private dirs, Pos/POS_MAX/Anchor360, language names, cache/model file names) to break them.

## Requirement -> test map
- ai-docs/code-req-tests.md (file -> REQ numbers). Human view per area: docs/code-index.md.
