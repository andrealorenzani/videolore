# Changelog

Changes since the last release, newest first. Each entry: version and date-time. On release the entries become `releases/<version> - <name>/RELEASE_NOTES.md` and this file is cleaned.

## 1.6.3 — 2026-11-20 00:49 +0000

Workflow and housekeeping only; nothing changes for the users of the programs.

### Release 1.6.3 — core effects and player

Highlights since the previous release (1.6.0 to 1.6.3): a splash screen with the release summary at every start of the editor and the player; the video player `videolore-player`, with sound, subtitles and 360 look-around; the Apply LUT colour effect from `.cube` files, on one clip or the whole video; whole-video effects that give each clip its own copy (1.6.1); icons across the interface; the splash pictures' origin and licence recorded as the author's own work under MIT; and a reworked release flow with a project page regenerated for each release.

### Changed
- **Splash pictures**: the origin and licence of `splash.gif` and `splash-player.gif` are recorded in the third-party notices as the author's own work, licensed MIT (open until now).
- **Splash files have fixed names and are never copied per version**: `assets/splash/splash.gif` (editor) and `splash-player.gif` (player), with the texts `summary.txt` and `summary-player.txt` rewritten in place for each version. The old per-version files (`1.6.0.txt`, `1.6.1.txt`) are deleted; `src/splash.rs` includes the new paths (not rebuilt or tested in this change); the human docs and the third-party notice use the new names.

### Workflow
- **`/release` reworked**: a consolidation before the gate and the snapshot (the Documenter cleans and compacts `docs/` and the README known limitations; the Product Manager writes a prioritised `docs/roadmap.md` and `docs/roadmap_tasks.md`; the Principal Engineer, always on Opus, optimises code, tests and libraries and writes `docs/code-index.md` and `docs/code-architecture.md` with mermaid diagrams; the Architect verifies and stores the module architecture; each cleans what it owns). The architectural plans are archived in the release snapshot and removed from `ai-docs/`. A git-ignored temporary `github_page/after release.md` carries the page data. When the next major opens, the Documenter writes a new README poem and the Principal Engineer regenerates the project page.
- **Project page rules**: every regeneration points to the last release and its artefacts, with a "Download" link right after the project name.
- **`/analysis`** command and **`analyst`** agent: a read-only Haiku agent (`Read`, `Glob`, `Grep`) that answers questions about the project and writes nothing.

## 1.6.2 — 2026-11-20 00:17 +0000

The video player gets the editor's start screen, and the editor's splash shows a longer summary for each release.

### Added
- **Video player start screen (REQ-150)**: the player opens with a splash screen like the editor's, with its own picture (`assets/splash/videolore-player.gif`, added to the repository) and its own summary. It shows at every start without a video on the command line; a video on the command line opens at once, and opening a video closes it. This reverses the 1.6.0 rule that the player has no splash screen.

### Changed
- **Splash screen (REQ-134)**: the editor's picture is the fixed file `assets/splash/videolore.gif`, and the summary is about 2.5 times as long as the 1.6.0 text. The summary text is sized to fit the popup without scrolling, from 15 px down to 7 px. Each program has its own summary per release (`assets/splash/<version>.txt` for the editor, `<version>-player.txt` for the player).
- **Splash code (architecture)**: one shared splash module for both programs, `videolore::splash` with the `EDITOR` and `PLAYER` programs and `videolore::ui::splash_window`; the four asset files are compiled in, the GIF is decoded under a 64 MiB total cap, and no crate is added.

### Removed
- `assets/splash/1.6.0.gif` (byte-identical to `videolore.gif`); `assets/splash/1.6.1.gif` is renamed to `videolore.gif`. `1.6.0.txt` and `1.6.1.txt` stay as history and are not read by the build.

### Workflow
- Every version needs its own `assets/splash/<version>.txt` and `assets/splash/<version>-player.txt`: the build fails without them. The picture files do not change per version.
- A memory cap of 8 GB for builds and tests on the development machine is used in development; it is not yet a written workflow rule.

### Quality
- Line coverage 95.6%; feature coverage 148 of 148 implemented requirements have a test.

## 1.6.1 — 2026-11-19 23:13 +0000

### Changed
- **Whole-video effects (business)**: an effect applied to the whole video (double-click) is applied to every clip on the timeline at that moment and stays with those clips; clips added later do not get it. Whole-video Fade IN/OUT is a fade in at the first clip and a fade out at the last clip, so start and end fades now belong to the clips. A whole-video Scale or Move gives each clip its own copy of the keyframes, and a whole-video Apply LUT gives each clip its own LUT. The picture's Scale box and the subtitle and text boxes resize from their visible edges when they are partly outside the picture. The effects part of the requirements moved to `docs/business-effects.md`. The splash of 1.6.1 has a new summary and reuses the 1.6.0 image.
- **Projects (architecture)**: project format 9 stores whole-video effects on the clips (each clip has its own start and end fade, Scale and Move keyframes and LUT). Format 8 files from 1.6.0 are converted once on open, with one status note: a clip's own Scale or Move and the whole video's become one combined path, and a clip's own LUT wins over the whole video's. Projects from 1.6.0 otherwise open with the same result.
- **Build (CI)**: the check job has a 30-minute timeout, installs only the missing apt packages with `--no-install-recommends` and retries, and gets cargo-about 0.9.3 from the taiki-e install action (support not verified yet; fallback in the roadmap).

### Fixed
- **Paused preview**: a paused preview no longer stays black. A skipped or superseded request left a stale posted key, so the picture at the playhead was not drawn again (REQ-144).

### Quality
- A test that built about 10 GB of subtitle titles now builds 1000 tracks of 100 KB each; its assertions are unchanged.
- New golden argument fixtures for the 1.6.1 export, named `export-argv-<version>-in-1.6.1.txt`, beside the frozen ones of earlier versions.
- Line coverage 95.5%; every requirement marked implemented has a test.

### Known limitations
- Clips added after a whole-video effect do not get it, and nothing says so.
- After a clip's keyframes are changed alone, the whole-video Scale or Move popup shows and changes only the first clip's keyframes.
- A text item's width changes only from its right edge.
- A 1.6.0 clip with its own and a whole-video Scale or Move becomes one combined path: exact at the keyframe times, a straight line between them.

## 1.6.0 — 2026-11-19 21:27 +0000

A splash screen at every start of the editor, a separate video player (videolore-player) for watching videos, the Apply LUT colour effect, and icons across the interface. Projects saved by this version (project format 8) need version 1.6.0 or later.

### Added
- **Requirements (business)**: new `docs/business-splash.md` (REQ-133, REQ-134), `docs/business-lut.md` (REQ-135 to REQ-137), `docs/business-player.md` (REQ-138 to REQ-141) and `docs/business-icons.md` (REQ-142, REQ-143), all implemented; `docs/business.md` index and the Video player and Apply LUT sections linked from it.
- **Code**: the splash screen (`assets/splash/<version>.gif` and `.txt`, no splash when a file is given on the command line); Apply LUT with a `.cube` reader for 3D and 1D LUTs (project format 8); the videolore player as a second program in a workspace (`player` crate), with its own build and installers (`scripts/package.sh <target> player`) and its own notices; Phosphor Icons (MIT licence, bundled as a font) across the editor and the player; `image` 0.25.10 (GIF only) and `rfd` 0.18.0 added as dependencies.

### Changed
- **Requirements (business)**: REQ-069 and REQ-075 are implemented again, reworded for the Apply LUT effect and the new icons; impact notes in the UI, editing and business documents for the LUT, the markers, the drag and the icons.
- **Architecture**: `docs/architecture.md` is an index with sub-documents for the splash screen, Apply LUT, the videolore player (second program with its own installers, reusing the preview engine), icons and build, CI and versions (two-product workspace); the player uses the editor's icon artwork; the splash image stays static.
- **Accepted deviations (code)**: the LUT is applied to the fitted picture before the frame effect; a missing or damaged LUT is reported in the "could not be found or were repaired" notice; the Change aspect row in the Effects list has no tooltip and cannot be dragged (not fixed); the player plays very large videos from a silent preview copy.
- **Workflow**: every version bump needs its own `assets/splash/<version>.gif` and `assets/splash/<version>.txt`.

## 1.5.0 — 2026-11-19 19:02 +0000

Change the aspect of the whole video, scale and move pictures with keyframes, and fill the empty space with a colour or a blurred copy of the video. Projects saved by this version need version 1.5.0 or later (project format 7); 1.4.x refuses them and leaves them untouched.

### Added
- **Requirements (business)**: new `docs/business-frame.md` with the frame features, REQ-124 to REQ-132 implemented: Change aspect (shape, fit, colour or blurred fill), frame size, Scale and Move with keyframes, the Effects list and menus, composition order, project format 1.5.0.
- **Architecture**: new `docs/architecture-frame.md` with the frame design (the 4096 px cap of the longer side, decided on 2026-11-19, composition order, keyframes, filter graph, export and preview rules, format 7, tests, risks); no new crate.
- **Code**: new modules `keyframes.rs` (keyframe lists) and `frame.rs` (frame model and ffmpeg expressions), with `app/frame.rs`, `ui/frame_popups.rs` and `ui/frame_handles.rs`; the picture is composed in the same ffmpeg graph for preview and export; project format 7. The ffmpeg expression spike is OK on 6.1.1: time-dependent sizes and positions are accepted. Real-ffmpeg tests in `tests/ffmpeg_integration/v15.rs`.

### Changed
- **Requirements (business)**: impact notes in the UI, export, picture, text and editing documents; a 360 video export ignores the three frame effects, and a 360 clip's Scale and Move act on its flat camera view only.
- **Code, deviations from the plan**: the picture is fitted to the frame, so the frame size is set first and the video is scaled into it (for example 9:16 with Fit on height gives a 676x1200 frame, with the picture cut at both sides); damaged frame values in a project file are corrected silently and never refuse the file; one popup at a time; a drag of a handle creates a keyframe at the playhead when none is selected; the blur radius of the blurred fill is clamped to the range of `boxblur`.

### Quality
- Line coverage 95.7%, feature coverage 129/129: REQ-124 to REQ-132 are implemented and each has a test.

## 1.4.1 — 2026-11-18 00:01 +0000

The project page is rewritten: a short introduction with the director animation, the evolution of the project, the key features with their images, the availability and what it is built with. It is also lighter on phones and for users who prefer reduced motion, which see still pictures; the timeline can be scrolled from the keyboard, and the page has share tags (canonical and Open Graph).

The quality suite was not run locally: only the page changed, no Rust code changed, and the local environment lacks the ALSA development files that clippy needs. CI runs the suite after the push.

### Changed
- **Project page** (`github_page/index.html`): rewritten with a 3-line introduction, "Evolution of this project", "Key features" with alternating side images, "Availability" and "Built with"; the GIF images are in `github_page/images/`. The software is unchanged.
- **Project page, lighter and more accessible**: on phones and with reduced motion the images are still PNG pictures (`<picture>` with six `*-still.png` files in `github_page/images/`); images have width, height and lazy loading; the timeline region is keyboard-scrollable; the page has canonical and Open Graph tags and an empty favicon.

## 1.4.0 — 2026-11-17 21:16 +0000

Export choices, Clean audio, text boxes that fit their text, and items that can be dragged past the picture edges (REQ-114 to REQ-123; REQ-022, REQ-023, REQ-069, REQ-075, REQ-089, REQ-097, REQ-100, REQ-103, REQ-106 and REQ-111 reworded). Projects saved by this version need version 1.4.0 or later.

### Added
- **Export dialog**: File > Export…, the toolbar button and Ctrl/Cmd+E open a dialog with the export file (folder, name, extension set by the format), a mode (Full video, Only audio, Only subtitles (.srt)), a video format (Same as source, or one of 12 presets: H.264 or HEVC, MP4 or MOV, several resolutions and frame rates), an audio format (Same as source, aac, or mp3 when the bundled ffmpeg can encode it), and, for a project whose video clips are all 360, the choice between a 360 video and a flat camera view.
- **Clean audio**: an on/off effect of the video's sound, on one clip or on the whole video, in the Effects list. It reduces background noise such as wind, music or people chatting, in the preview and in the export. It does not change the music track.
- **Text boxes that fit the text**: a text item's box changes width only, from its right edge; its text size follows the box (best fit) and the text wraps inside it.
- **Dragging past the picture edges**: text items and subtitle lines can be dragged partly outside the picture; the centre of the box stays on the picture, so the box can always be grabbed again.
- **Context Menu for text items**: Align horizontally, Align vertically and Reset work on a selected text item, as on subtitle lines.

### Changed
- The "Treat as 360° video" switch of Clip details is removed: a clip is 360 only when its file carries spherical information. A 360 switch set in a 1.3.0 project is dropped when the project opens.
- Text items of 1.3.0 projects are migrated: their text size becomes the best fit of their box, so large multi-line texts may shrink when the project opens.
- Projects are saved in format 6. Projects from 1.3.0 and earlier open with the same result, with the two changes above; projects saved by 1.4.0 cannot be opened by 1.3.0 or earlier.
- The Effects menu lists only effects; commands that act on subtitles, fades or picture items are in the Edit menu.
- The output format stays automatic by default ("Same as source"); the Export dialog only changes it when a format is chosen.

### Quality
- Line coverage 95.8%; 103 of 103 implemented requirements have tests (REQ-114 to REQ-123 added).

### Known limitations
- Clean audio has one fixed strength: it reduces noise but does not remove it completely. Quiet speech (about -32 dB) can lose up to about 2.5 dB, and its cost on weak computers is not measured.
- The best-fit text size is an estimate: a text can fill about 85% to 115% of its box. Short texts become large and long ones small; a 1.3.0 text that does not fit its box may shrink when opened.
- A text or subtitle line dragged past an edge of the picture is cut in the preview and in the export.
- The Export dialog remembers its choices for the session only, not in the project or in Settings; the formats are a fixed list of presets.
- A 360 video ignores the video format presets and keeps the sphere's own size.
- A video without spherical information is always flat, since the 360 switch is removed.

## 1.3.0 — 2026-11-17 19:08 +0000

Text items, one selection for the preview and the timeline, and 360 video export: titles and captions on the picture, texts and subtitle lines that stay at their point of a 360° sphere, and a 360 video that keeps the whole sphere.

### Added
- **Text items**: the "Add Text" row in the Effects list (or Effects > Add text at playhead) writes a multiline text at the playhead, in a colour and a font installed on the computer (the bundled subtitle font by default). Each text has the effects Fade IN, Fade OUT, Blink and Slide in, in any combination, each with its own time. A text is shown for its time to live, drawn as a bar on a new Text lane of the timeline (drag the bar to move it or to change its length), and has a box on the picture that moves and resizes like a subtitle line; it is burned into the export (REQ-108 to REQ-111). See [Text](business-text.md).
- **One selection for lines and texts**: Ctrl/Cmd+click or Shift+click adds a subtitle line or text item to the selection, Shift+drag on the timeline selects those that start in a range, and dragging a selected box in the preview moves the whole selection (REQ-090 to REQ-092).
- **Texts and subtitle lines on 360 clips**: a text or a subtitle line added on a 360 clip stays at the point of the sphere the camera is looking at, so it does not move when the camera turns (REQ-112).
- **360 video export**: for a project with 360 clips, Export asks between a 360 video, which keeps the whole sphere with the texts at their points, and the flat camera view (REQ-103).
- **Context Menu**: a toolbar group with Align horizontally, Align vertically, Set POV and Reset, shown only when it has something to act on (REQ-106).

### Changed
- "Fade through black" is named "Fade IN/OUT" everywhere; its behaviour is unchanged (REQ-107).
- A project with text items or 360 anchors is saved in format 5 (REQ-113). Projects saved by 1.3.0 cannot be opened by 1.2.6 or earlier; older projects open unchanged.
- A project with a text item is re-encoded on export, with the hardware export too (REQ-023, REQ-062).
- The installed fonts are listed with one new library, `fontdb` 0.24.0.

### Quality
- Line coverage 96.0%; feature coverage 96/96 (REQ-023, REQ-075, REQ-090 to REQ-092, REQ-098, REQ-099, REQ-102, REQ-103 and REQ-106 to REQ-113 implemented).

### Known limitations
- Text items have no outline, shadow or background box, use the fonts installed on the computer (so they can look different on another computer) and are not written to the `.srt` file.
- A subtitle line placed on a 360 clip is drawn as plain white text (no preset box, no word highlight).
- A 360 video export carries its 360 marker only in MP4 and MOV files.
- A project file with a text whose time to live is above 24 hours, or below 0.1 s, is refused as damaged on opening; while editing, a text's time to live is limited to the video's length.
- The 360 video export is slow; no speed is promised.

## 1.2.8 — 2026-11-17 18:59 +0000

### Workflow
- Commit messages stay one line but may now include the co-author trailer as the only extra line (rule 9).

## 1.2.7 — 2026-11-17 18:55 +0000

### Workflow
- Agent models: Product Manager, Architect and Documenter run on Haiku; the Principal Engineer runs on Opus when the session model is Opus, otherwise on Sonnet (new rule 13 in the workflow rules).

## 1.2.6 — 2026-11-16 23:30 +0000

Boxes on the picture and 360 video: every movable object on the picture gets a visible box that moves and resizes, a group of Align and Reset commands is added to the toolbar, and 360° videos can be looked around in and exported as a flat video that follows a camera path set by the user.

### Added
- **Boxes on the picture**: the preview draws a thin box around each movable object (today the subtitle lines); drag it to move, drag a corner to enlarge or shrink. The box is never exported, and View > Show boxes on the picture hides it. One drag is one undo step. Requirements REQ-096 and REQ-097 in [Boxes on the picture and 360 video](business-picture.md).
- **Align horizontally, Align vertically and Reset**: a separate toolbar group, also in the Effects and right-click menus, with shortcuts and tooltips. Align centres the selected object(s) on the picture on that axis; Reset returns a subtitle line to its style's place and 100% size, or a 360 view to the front (REQ-098, REQ-099).
- **Per-line text size**: each subtitle line can be 25–400% of its style's text size, set with its box, kept in the project and shown the same in the preview and the export (REQ-097).
- **360° video**: a full equirectangular 360° video is recognised from its file information (or set per clip with "Treat as 360° video") and shown as a camera view; drag to look around, mouse wheel or pinch to zoom, during playback too. **Set POV** stores the view at the playhead; between POVs the camera moves in a straight line at constant speed, and the path follows the clip when it is split or trimmed (REQ-100 to REQ-102). The camera view is made from a preview copy for large sources, and every interface frame stays under 200 ms while looking around (REQ-104).
- **360 export**: a 360 clip is exported as a normal flat video of the camera path, with fades, subtitles, music and volumes (REQ-103). Architecture in [360 video](architecture-360.md) and [boxes](architecture-boxes.md).

### Changed
- **Project format version 4** (REQ-105): stores the subtitle line sizes, the "360°" switch of each clip and the POVs of each source. Projects from 1.2.5 and earlier open with the same result; projects saved by 1.2.6 cannot be opened by 1.2.5 or earlier.

### Known limitations
- Exporting a 360 clip with a moving camera runs at about one third of real time (a 30 s clip takes about 90 s); the interface stays responsive meanwhile.
- Only single-picture equirectangular 360 video is supported; spatial sound is played as it is and does not follow the camera; no camera roll; no keyboard control of the camera.
- Align horizontally does nothing for a line that is already at the style's place; an enlarged line's text may wrap and shift its centre slightly.
- Subtitle lines shown at the same time can overlap after moving or enlarging.

### Quality
- Line coverage 96.0%; feature coverage 105/105 (REQ-096 to REQ-105 added and implemented).

## 1.2.5 — 2026-11-16 22:40 +0000

Workflow only: no change to the program or to what the app does.

### Workflow
- **Notes are indexes**: each `ai-docs/` file starts with an index of every paragraph of the human docs its owner manages (`- <file> § <heading> — L<start>-<end> (<n> lines)`), so an agent finds a paragraph with `grep` and reads only its lines. Detail that only an AI needs goes in `ai-docs/<area>-<topic>.md`, indexed from the main file. The current long notes are converted by their owners in their next development (roadmap).
- **Feature pipeline by files**: the product-manager and the architect write their plans into the notes and docs and return only their `[SEVERE]` questions; the principal-engineer returns its results. The command relays only the user's answers, file paths and counts, not the agents' reports.
- **Documenter after each part**: the documenter runs after the business, architecture and code parts, and updates the docs only. The version is bumped once per development. It may write any `docs/` file and the README, with no owner guardrail; it never edits another agent's notes.
- **README poem**: rewritten only when a new major version is released; other README changes keep it.
- **Docs compaction**: on each release the documenter reads and compacts every `docs/` file, removing only useless data. Done once now: the workflow doc was rewritten, the business UI doc lost repeated text, and the roadmap workflow item was updated. The other docs were checked for repeated lines (four found, kept as summaries) and will be read in full at the next release.

## 1.2.4 — 2026-11-15 22:02 +0000

Workflow only: the project page can be published.

### Workflow
- **Fixed the Pages deployment**: the workflow no longer asks GitHub to switch Pages on (the default token is not allowed to), so the deployment step failed. Turning Pages on is now a one-time manual step, see 1.2.3.

## 1.2.3 — 2026-11-15 22:01 +0000

Workflow only: the project page is published on GitHub Pages.

### Workflow
- **GitHub Pages deployment** with `.github/workflows/pages.yml`: on every push to `main` that changes `github_page/`, the page is published with the official Pages actions, pinned to commit SHAs like the other workflows. It can also be started by hand. Before the first run, turn Pages on once in the repository settings: Settings → Pages → Build and deployment → Source: GitHub Actions.

## 1.2.2 — 2026-11-15 21:59 +0000

A project page for the GitHub repository: the brief, the story of the project as a timeline of every version, and the copyright and licence.

### Added
- **GitHub project page** in `github_page/index.html` (one static page, no build step): the brief taken from the README, the story as a horizontal timeline from the first commit (13 November 2026) to today, with each version's number, date and time and a sentence on what it is, and the copyright and licence. It scrolls sideways on phones and follows the light or dark setting.

## 1.2.1 — 2026-11-15 21:52 +0000

Workflow only: no change to the program or to what the app does.

### Workflow
- **Fewer tokens for each development.** The Documenter no longer reads all of `docs/` (355 KB at 1.2.0) each time: `scripts/docs-check.sh` checks links, sub-document indexes, forbidden AI/agent terms, changelog headers, and the README's latest changes and poem, and the Documenter reads in full only the files the development changed. A full prose read happens on release.
- **Shorter test reports.** The Principal Engineer runs the tests in quiet mode and reads only the summaries and the failures, not the full logs.
- **Rule 12 (token economy)** in `AGENTS.md`: agents read only what their task needs; long notes are compacted by their owner, never by another agent.
- Considered and not done: merging agents (saves one cold start per feature, the notes still dominate the cost) and compacting the notes now (owners' files, planned in the roadmap). Details in `docs/workflow.md`, section Token economy.

## 1.2.0 — 2026-11-15 21:42 +0000

Effects can be applied to one clip or to the whole video, subtitles can reuse a video's own subtitle track, and each subtitle line can be moved on the picture. Projects saved by this version use a newer format: versions 1.1.0 and earlier cannot open them.

### Added
- **Apply an effect to one clip or to the whole video.** Drag an effect from the Effects list onto a clip, or right-click the clip and choose Effects. Double-click an effect in the list to apply it to the whole video.
- **Fade through black at the start and at the end** of the video, in the same way as the fades between clips. The end fade starts two frames early, so the last frame is black.
- **Volume and mute per clip**, through the Volume effect, on one clip or on the whole video.
- **Subtitles for one clip**: the subtitles effect creates lines only for the part of the source the clip uses; the lines of the other clips are untouched. The undo step reads "Create subtitles" for a clip and "Generate subtitles" for the whole video.
- **Use a video's own subtitles.** When a video contains a text subtitle track (SRT, ASS/SSA, MP4 timed text or WebVTT), videolore asks whether to use its text or to recognise the speech. Using the text keeps the words and the line times exactly, and the words are matched to the speech. Picture-based tracks (DVD, Blu-ray, DVB) are ignored. A track with an unknown language is labelled by its code, or "Track N". Media imported before 1.2.0 is checked in the background when a project is opened.
- **File > Export subtitles (.srt)…** writes the lines as they are on the timeline, after cuts, trims and copies. It is greyed out when there are no subtitles.
- **Subtitle positions**: drag a subtitle line in the preview to its own place. The text box stays inside the picture, each drag is one undo step, and Reset position restores the style's place.
- **Several lines at once**: Ctrl/Cmd+click on subtitle markers or on lines in the Subtitles list adds or removes a line from the selection; Shift+drag on the timeline selects every line that starts in the dragged range. Dragging one selected line moves the whole group to the same place.
- **Timeline ruler** shows seconds up to 90 seconds, minutes and seconds up to 90 minutes, and hours and minutes beyond.

### Changed
- The Effects list shows the effect names only, without counts or levels.
- A fade applied to a clip opens the Fades list popup.
- A recognition failure during matching shows a notice dialog and the number of lines that could not be matched; the lines keep the video's text and times.
- Project format version 3. Projects saved by 1.2.0 cannot be opened by 1.1.0 or earlier: those versions refuse them with the "newer version" message and leave the file untouched. Projects saved by earlier versions open unchanged.

### Quality
- Line coverage 95.9%; feature coverage 95/95 (REQ-082 to REQ-095 added, some requirements reworded). Tests: 310 unit (1 ignored) and 29 integration (3 ignored); fmt, clippy, coverage and version checks pass.

### Known limitations
- When a video's own subtitles are reused, the word-by-word highlight timing is approximate. The accuracy target (at least 90% of words matched, each within 0.3 s) is not met yet with the Fast model: on the reference clip 23 of 28 words (82%) were matched, with word starts 0.48 s off on average and 1.10 s at worst. The strict test is marked ignored until the target is met.
- Matching works only as well as the track's text follows the speech; translated or paraphrased tracks often get evenly spread words.
- Subtitle lines moved to their own place are not kept apart: two lines shown together can overlap.
- Editing a line's text after moving it can make it larger, and in the export it can then reach past the edge of the picture; drag it again or use Reset position.
- Start and end fades stay at the video's edges when clips are moved.
- The `.srt` export has no positions.
- Drag and drop does not work in Linux Wayland sessions (as in 1.1.0).

## 1.1.0 — 2026-11-15 17:52 +0000

The window is reorganised around a menu bar, a toolbar, a status bar, resizable sections and an Effects list. Projects and the project file format are unchanged.

### Added
- **Menu bar** with File, Edit, Playback, Effects, View and Help. Each item shows its shortcut and is greyed out exactly when its command is not available; the greyed main commands explain why in a tooltip (for example "Select a clip first" or "Nothing to undo").
- **Toolbar** with Import, Add to timeline, Add music, Split, Cut, Copy, Paste, Delete, Undo, Redo, Play/Pause and Export (Cancel export while exporting). When the window is narrow, the buttons that do not fit go into a "»" menu.
- **Status bar**: the latest message on the left; background work with progress in the middle (import analysis, preview copies, speech model download, subtitle generation and export), with Cancel for subtitles and export; the output file on the right.
- **Resizable sections**: drag the borders between Media and Preview, between Timeline and Effects, and between the top and bottom rows. The sizes are remembered for the next start, and View > Reset layout restores the default layout.
- **Effects section** listing Fade through black, Subtitles and Volume, with a count or the current levels. Each one opens its own settings window, which does not block editing or playback.
- **Markers on the timeline** for every fade and every subtitle line. Clicking a marker opens the settings of that fade or line. Where two clips meet without a fade, an "Add fade" handle adds one. Overlapping markers open a small list to choose from.
- **Clip details** window: double-click a clip, or use Edit > Clip details…, to trim, set fades, merge, move, split or delete it.
- **Right-click menus** on video and music clips, on markers and on the empty timeline.
- **Open recent**: File > Open recent lists the last 10 projects, most recent first, with Clear list. A project that is no longer there is reported and removed from the list.
- **Drag and drop** of media files onto the window to import them, and of a project to open it (Windows, macOS and Linux with X11). If several projects are dropped, the first one opens and the others are reported as ignored.
- **Keyboard shortcuts**: N new project, O open, Shift+S save as, I import, E export, Delete or Backspace to delete, Left and Right to step one frame, Home and End to go to the start and end, Ctrl/Cmd+= and Ctrl/Cmd+- to zoom, Ctrl/Cmd+0 to fit the project, F1 for the Keyboard shortcuts window. Esc closes the topmost popup. Shortcuts never fire while typing in a text field or while a dialog is open.
- **Undo and Redo name the action**: Edit > "Undo Split", "Redo Remove fade".
- **Scrollbars** wherever content can overflow, so every control and text stays reachable with the window at 800x500.

### Changed
- Window layout from top to bottom: menu bar, toolbar, content area, status bar. The content area has Media (30% of the top row) beside Preview (70%), and Timeline (70%) beside Effects (30%) in the bottom row, which takes one third of the height. Each section has a title.
- The zoom slider is in the Timeline header; View > Zoom in, Zoom out and Fit project zoom too.
- Export and its progress moved to the File menu, the toolbar and the status bar. The command bar is replaced by the toolbar.
- Clicking a fade marker opens its settings instead of removing the fade. A fade is removed from its settings or from the right-click menu.
- Video and music volume are in the Volume window; trim and music controls are in the Clip details window.
- Settings is in the Edit menu; Ctrl/Cmd+, still opens it.
- The keyboard shortcut list moved from the Effects section to Help > Keyboard shortcuts.
- Ctrl/Cmd+= and Ctrl/Cmd+- zoom the timeline; the window no longer changes its text size with them.
- Long file names are shortened with "…", with the full name in a tooltip.

### Removed
- The command bar at the top of the window, replaced by the menu bar, the toolbar and the status bar.

### Quality
- Line coverage 96.1%; feature coverage 81/81 (REQ-024 and REQ-025 reworded, REQ-066 to REQ-081 added). Tests: 263 unit and 23 integration; fmt, clippy, coverage and version checks pass.

### Known limitations
- Drag and drop does not work in Linux Wayland sessions; use File > Import media… and File > Open….
- Versions before 1.1.0 drop the saved layout and the recent-projects list when they save their settings.
- Popup positions and the window size and position are not remembered between sessions.
- Ctrl/Cmd+V pastes clips only when the system clipboard holds text. Paste in the menu and toolbar always works.

## 1.0.0 — 2026-11-14 22:36 +0000
- Version 1.0.0 opened after release 0.4.2 "MVP". No user-facing changes yet.

## 0.4.3 — 2026-11-14 22:35 +0000

Fixes the macOS and Windows installers, which the 0.4.2 installer job could not build. The Linux installers of 0.4.2 were unaffected. The macOS and Windows installers of 0.4.2 are not in its GitHub release; they are confirmed only when the installer job runs again.

### Fixed
- The generated cargo-packager configuration (`scripts/package.sh`) had four errors, all fixed: the file association role is `editor` (was `Editor`), the NSIS key is `installMode` (was `install-mode`), `name = "videolore"` is present (without it cargo-packager stops with "Not a directory"), and all paths are absolute, because cargo-packager reads relative paths from the folder of the configuration file (on Windows they are written with `cygpath -m`).
- Missing DLLs of the Windows ffmpeg build, and a missing produced installer or `.app`, now stop the script with a clear error.

### Added
- `scripts/package.sh <target> --config-only` writes only the configuration (no ffmpeg, no build), so it can be checked on any machine.
- Test `packaging::tests::packager_config_is_valid_for_cargo_packager` checks the keys, enum values and paths of both configurations (covers REQ-040, REQ-041, REQ-042).

### Changed
- `hdiutil create` for the macOS disk image is retried up to 5 times.
- Validated locally with the real cargo-packager 0.11.8: the deb and app formats were built from both configurations, and the NSIS script was generated.

### Quality
- Line coverage 96.3%; feature coverage 65/65. Tests: 223 unit and 23 integration, 2 ignored; fmt, clippy, coverage and version checks pass.