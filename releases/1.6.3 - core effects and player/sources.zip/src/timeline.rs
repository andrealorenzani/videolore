// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Andrea Lorenzani

//! The single video track: a contiguous list of clips (no gaps, no overlaps) plus the set of
//! boundaries that carry a fade. Every edit is a method returning `Result<_, EditError>`.

use crate::frame::{self, FrameAspect, Scale, Stack, Track};
use crate::keyframes::{self, Key, KeyError};
use crate::media::{MediaId, MediaItem};
use crate::subtitles::Pos;
use crate::time::Micros;
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

/// Longest fade at a boundary.
pub const MAX_FADE: Micros = Micros(500_000);

#[derive(
    Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Default,
)]
#[serde(transparent)]
pub struct ClipId(pub u64);

/// Full volume of a clip's own sound (percent).
pub const FULL_VOLUME: u8 = 100;

fn full_volume() -> u8 {
    FULL_VOLUME
}

/// A slice `[src_in, src_out)` of a media item placed on the track.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Clip {
    pub id: ClipId,
    pub media: MediaId,
    pub src_in: Micros,
    pub src_out: Micros,
    /// Level of the clip's own sound, 0–100 % (1.2.0; absent = 100).
    #[serde(default = "full_volume")]
    pub volume: u8,
    /// The clip's own sound is muted (1.2.0; absent = not muted).
    #[serde(default)]
    pub muted: bool,
    /// Background noise of the clip's own sound is reduced (1.4.0, REQ-114; absent = off).
    #[serde(default)]
    pub clean_audio: bool,
    /// A fade in from black at this clip's start, used when the clip is the first one
    /// (1.6.1, REQ-083: it belongs to the clip; absent = none).
    #[serde(default, skip_serializing_if = "is_false")]
    pub fade_in: bool,
    /// A fade out to black at this clip's end, used when the clip is the last one.
    #[serde(default, skip_serializing_if = "is_false")]
    pub fade_out: bool,
}

fn is_false(b: &bool) -> bool {
    !*b
}

impl Clip {
    /// A clip at full volume, not muted.
    pub fn new(id: ClipId, media: MediaId, src_in: Micros, src_out: Micros) -> Clip {
        Clip {
            id,
            media,
            src_in,
            src_out,
            volume: FULL_VOLUME,
            muted: false,
            clean_audio: false,
            fade_in: false,
            fade_out: false,
        }
    }

    /// True when the clip's sound is changed (level below 100 % or muted).
    pub fn has_volume(&self) -> bool {
        self.volume != FULL_VOLUME || self.muted
    }

    pub fn len(&self) -> Micros {
        self.src_out - self.src_in
    }

    pub fn is_empty(&self) -> bool {
        self.len() <= Micros::ZERO
    }

    /// Length of the fade applied at either end of this clip.
    pub fn fade_len(&self) -> Micros {
        MAX_FADE.min(Micros(self.len().0 / 2))
    }
}

#[derive(Debug, thiserror::Error, PartialEq, Eq, Clone)]
pub enum EditError {
    #[error("no such clip")]
    NoSuchClip,
    #[error("the playhead is not inside a clip")]
    NotInsideClip,
    #[error("'{0}' has no video: audio files go on the music track")]
    NoVideo(String),
    #[error("'{0}' is missing")]
    MissingMedia(String),
    #[error("these clips cannot be merged: they must be adjacent parts of the same file")]
    NotMergeable,
    #[error("invalid range")]
    InvalidRange,
    #[error("no boundary there")]
    NoSuchBoundary,
    #[error("the clipboard is empty")]
    EmptyClipboard,
    #[error("no clip selected")]
    NothingSelected,
    #[error("nothing to undo")]
    NothingToUndo,
    #[error("nothing to redo")]
    NothingToRedo,
    #[error("the timeline is empty")]
    EmptyTimeline,
    #[error("{0}")]
    Key(KeyError),
    #[error("the picture has no such effect")]
    NoSuchEffect,
}

/// Why two clips cannot be merged although they are parts of the same file.
pub const DIFFERENT_VOLUMES: &str = "The clips have different volumes";

/// Why two clips cannot be merged: one has Clean audio and the other has not.
pub const DIFFERENT_CLEAN_AUDIO: &str = "The clips have different clean audio settings";

/// Why two clips cannot be merged: their Scale or Move keyframes differ (1.5.0).
pub const DIFFERENT_FRAMES: &str = "The clips have different frame settings";

/// Why two clips cannot be merged: their Apply LUT files differ (1.6.0).
pub const DIFFERENT_LUTS: &str = "The clips have different colour effects";

/// What a Scale, Move or Apply LUT is applied to (REQ-130). Since 1.6.1 `Whole` is not a
/// state of its own: reading it gives the first clip's copy and a change reaches the copy of
/// every clip (REQ-148); the time of a `Whole` key is clip time shifted by the first
/// clip's source start.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum FrameTarget {
    Whole,
    Clip(ClipId),
}

/// The Scale and Move keyframes of one clip, in SOURCE time of the clip's media (ADR-094):
/// a trim or split never deletes or shifts them.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ClipFrames {
    pub clip: ClipId,
    #[serde(default)]
    pub scale: Vec<Key<Scale>>,
    #[serde(default)]
    pub moved: Vec<Key<Pos>>,
}

/// The Apply LUT file of one clip (1.6.0, ADR-111): the path of a `.cube` file.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ClipLut {
    pub clip: ClipId,
    pub path: String,
}

/// The video track.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct Timeline {
    pub clips: Vec<Clip>,
    /// Boundaries with a fade, as (left clip, right clip). Only adjacent pairs are kept.
    pub fades: BTreeSet<(ClipId, ClipId)>,
    pub next_clip_id: u64,
    /// Change aspect of the whole video (1.5.0, REQ-124); `None` = no effect.
    #[serde(
        default,
        deserialize_with = "frame::lenient_aspect",
        skip_serializing_if = "Option::is_none"
    )]
    pub frame_aspect: Option<FrameAspect>,
    /// Scale and Move keyframes of the clips, sorted by clip id; empty entries are removed.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub clip_frames: Vec<ClipFrames>,
    /// Apply LUT of the clips, sorted by clip id; empty entries are removed.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub clip_luts: Vec<ClipLut>,
}

impl Timeline {
    fn new_id(&mut self) -> ClipId {
        self.next_clip_id += 1;
        ClipId(self.next_clip_id)
    }

    pub fn duration(&self) -> Micros {
        self.clips.iter().fold(Micros::ZERO, |a, c| a + c.len())
    }

    pub fn index_of(&self, id: ClipId) -> Option<usize> {
        self.clips.iter().position(|c| c.id == id)
    }

    pub fn get(&self, id: ClipId) -> Option<&Clip> {
        self.clips.iter().find(|c| c.id == id)
    }

    /// Timeline start of clip `index`.
    pub fn start_of(&self, index: usize) -> Micros {
        self.clips[..index.min(self.clips.len())]
            .iter()
            .fold(Micros::ZERO, |a, c| a + c.len())
    }

    /// Clip containing `t` (`start <= t < end`) and its start.
    pub fn locate(&self, t: Micros) -> Option<(usize, Micros)> {
        let mut start = Micros::ZERO;
        for (i, c) in self.clips.iter().enumerate() {
            let end = start + c.len();
            if t >= start && t < end {
                return Some((i, start));
            }
            start = end;
        }
        None
    }

    /// Whether boundary `b` (between clips `b` and `b + 1`) has a fade.
    pub fn has_fade(&self, b: usize) -> bool {
        match (self.clips.get(b), self.clips.get(b + 1)) {
            (Some(a), Some(n)) => self.fades.contains(&(a.id, n.id)),
            _ => false,
        }
    }

    /// Fade-in and fade-out lengths for clip `index` (zero when absent). The first clip
    /// fades in when its own fade-in is set, the last one fades out when its fade-out is.
    pub fn fades_of(&self, index: usize) -> (Micros, Micros) {
        let Some(c) = self.clips.get(index) else {
            return (Micros::ZERO, Micros::ZERO);
        };
        let last = index + 1 == self.clips.len();
        let fin = if (index > 0 && self.has_fade(index - 1)) || (index == 0 && c.fade_in) {
            c.fade_len()
        } else {
            Micros::ZERO
        };
        let fout = if self.has_fade(index) || (last && c.fade_out) {
            c.fade_len()
        } else {
            Micros::ZERO
        };
        (fin, fout)
    }

    /// Drops fades whose clips are no longer adjacent.
    fn prune_fades(&mut self) {
        let pairs: BTreeSet<(ClipId, ClipId)> =
            self.clips.windows(2).map(|w| (w[0].id, w[1].id)).collect();
        self.fades.retain(|p| pairs.contains(p));
    }

    fn rename_fade_left(&mut self, old: ClipId, new: ClipId) {
        let moved: Vec<_> = self.fades.iter().filter(|p| p.0 == old).copied().collect();
        for p in moved {
            self.fades.remove(&p);
            self.fades.insert((new, p.1));
        }
    }

    /// Appends a whole media item at the end of the track.
    pub fn append(&mut self, media: &MediaItem) -> Result<ClipId, EditError> {
        if media.missing {
            return Err(EditError::MissingMedia(media.name.clone()));
        }
        if !media.has_video() {
            return Err(EditError::NoVideo(media.name.clone()));
        }
        if media.duration <= Micros::ZERO {
            return Err(EditError::InvalidRange);
        }
        let id = self.new_id();
        self.clips
            .push(Clip::new(id, media.id, Micros::ZERO, media.duration));
        Ok(id)
    }

    /// Splits the clip under `at` into two adjacent clips. Both halves must be at least
    /// `min_len` long. Returns the id of the right half.
    pub fn split(&mut self, at: Micros, min_len: Micros) -> Result<ClipId, EditError> {
        let (i, start) = self.locate(at).ok_or(EditError::NotInsideClip)?;
        let c = self.clips[i];
        let offset = at - start;
        if offset < min_len.max(Micros(1)) || c.len() - offset < min_len.max(Micros(1)) {
            return Err(EditError::NotInsideClip);
        }
        let id = self.new_id();
        let cut = c.src_in + offset;
        self.clips[i].src_out = cut;
        // the right half keeps the clip's sound settings
        self.clips.insert(
            i + 1,
            Clip {
                id,
                src_in: cut,
                // the start fade stays with the left half, the end fade with the right one
                fade_in: false,
                ..c
            },
        );
        self.clips[i].fade_out = false;
        self.rename_fade_left(c.id, id);
        self.prune_fades();
        // both halves keep the whole path (ADR-101)
        if let Some(f) = self.frames_of(c.id).cloned() {
            self.put_frames(ClipFrames { clip: id, ..f });
        }
        // and the colour effect
        if let Some(p) = self.lut_of(FrameTarget::Clip(c.id)).map(str::to_string) {
            self.put_lut(id, Some(p));
        }
        Ok(id)
    }

    /// Removes a clip (cut / delete); following clips ripple left.
    pub fn remove(&mut self, id: ClipId) -> Result<Clip, EditError> {
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        let c = self.clips.remove(i);
        self.prune_fades();
        self.clip_frames.retain(|f| f.clip != id);
        self.clip_luts.retain(|l| l.clip != id);
        Ok(c)
    }

    /// Inserts a copy of `template` (fresh id) at `at`; a clip under `at` is split first.
    /// Everything after the insertion point ripples right.
    pub fn insert_at(
        &mut self,
        template: &Clip,
        at: Micros,
        min_len: Micros,
    ) -> Result<ClipId, EditError> {
        if template.is_empty() {
            return Err(EditError::InvalidRange);
        }
        let index = match self.locate(at) {
            None => self.clips.len(),
            Some((i, start)) if at == start => i,
            Some((i, start)) => {
                let c = self.clips[i];
                let offset = at - start;
                if offset < min_len || c.len() - offset < min_len {
                    // Too close to an edge to split: insert at the nearest boundary.
                    if offset.0 * 2 < c.len().0 { i } else { i + 1 }
                } else {
                    self.split(at, min_len)?;
                    i + 1
                }
            }
        };
        let id = self.new_id();
        self.clips.insert(
            index,
            Clip {
                id,
                fade_in: false,
                fade_out: false,
                ..*template
            },
        );
        self.prune_fades();
        Ok(id)
    }

    /// True when clip `id` and the next one come from the same file, are contiguous in it
    /// and have the same sound settings.
    pub fn can_merge(&self, id: ClipId) -> bool {
        self.contiguous_with_next(id) && self.merge_block_reason(id).is_none()
    }

    fn contiguous_with_next(&self, id: ClipId) -> bool {
        match self.index_of(id) {
            Some(i) if i + 1 < self.clips.len() => {
                let (a, b) = (&self.clips[i], &self.clips[i + 1]);
                a.media == b.media && a.src_out == b.src_in
            }
            _ => false,
        }
    }

    /// Why two parts of the same file next to each other cannot be merged (their volumes
    /// differ); `None` otherwise.
    pub fn merge_block_reason(&self, id: ClipId) -> Option<&'static str> {
        if !self.contiguous_with_next(id) {
            return None;
        }
        let i = self.index_of(id)?;
        let (a, b) = (&self.clips[i], &self.clips[i + 1]);
        if (a.volume, a.muted) != (b.volume, b.muted) {
            Some(DIFFERENT_VOLUMES)
        } else if a.clean_audio != b.clean_audio {
            Some(DIFFERENT_CLEAN_AUDIO)
        } else if self.keys_of(a.id) != self.keys_of(b.id) {
            Some(DIFFERENT_FRAMES)
        } else if self.lut_of(FrameTarget::Clip(a.id)) != self.lut_of(FrameTarget::Clip(b.id)) {
            Some(DIFFERENT_LUTS)
        } else {
            None
        }
    }

    /// Merges clip `id` with the next one (see [`Self::can_merge`]).
    pub fn merge(&mut self, id: ClipId) -> Result<(), EditError> {
        if !self.can_merge(id) {
            return Err(EditError::NotMergeable);
        }
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        let b = self.clips.remove(i + 1);
        self.clips[i].src_out = b.src_out;
        self.clips[i].fade_out = b.fade_out;
        self.fades.remove(&(id, b.id));
        self.rename_fade_left(b.id, id);
        self.prune_fades();
        self.clip_frames.retain(|f| f.clip != b.id);
        self.clip_luts.retain(|l| l.clip != b.id);
        Ok(())
    }

    /// Sets the source in/out points, clamped to `[0, media_duration]`.
    pub fn trim(
        &mut self,
        id: ClipId,
        src_in: Micros,
        src_out: Micros,
        media_duration: Micros,
        min_len: Micros,
    ) -> Result<(), EditError> {
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        let new_in = src_in.clamp(Micros::ZERO, media_duration);
        let new_out = src_out.clamp(Micros::ZERO, media_duration);
        if new_out - new_in < min_len.max(Micros(1)) {
            return Err(EditError::InvalidRange);
        }
        self.clips[i].src_in = new_in;
        self.clips[i].src_out = new_out;
        Ok(())
    }

    /// Moves a clip to position `index` (clamped); the others ripple.
    pub fn move_to(&mut self, id: ClipId, index: usize) -> Result<(), EditError> {
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        let c = self.clips.remove(i);
        let index = index.min(self.clips.len());
        self.clips.insert(index, c);
        self.prune_fades();
        Ok(())
    }

    /// Adds or removes the fade at boundary `b`. Returns whether the fade is now present.
    pub fn toggle_fade(&mut self, b: usize) -> Result<bool, EditError> {
        let (a, n) = match (self.clips.get(b), self.clips.get(b + 1)) {
            (Some(a), Some(n)) => (a.id, n.id),
            _ => return Err(EditError::NoSuchBoundary),
        };
        if self.fades.remove(&(a, n)) {
            Ok(false)
        } else {
            self.fades.insert((a, n));
            Ok(true)
        }
    }

    /// Applies (`on`) or removes "Fade IN/OUT" on a clip: the fades at both of its
    /// edges (the boundaries with its neighbours, the start fade when it is the first clip,
    /// the end fade when it is the last).
    pub fn set_clip_fades(&mut self, id: ClipId, on: bool) -> Result<(), EditError> {
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        let mut set = |pair: (ClipId, ClipId)| {
            if on {
                self.fades.insert(pair);
            } else {
                self.fades.remove(&pair);
            }
        };
        if i > 0 {
            set((self.clips[i - 1].id, id));
        }
        if i + 1 < self.clips.len() {
            set((id, self.clips[i + 1].id));
        }
        if i == 0 {
            self.clips[i].fade_in = on;
        }
        if i + 1 == self.clips.len() {
            self.clips[i].fade_out = on;
        }
        Ok(())
    }

    /// True when every fade of [`Self::set_clip_fades`] is there for clip `id`.
    pub fn clip_has_fades(&self, id: ClipId) -> bool {
        let Some(i) = self.index_of(id) else {
            return false;
        };
        let left = if i == 0 {
            self.clips[i].fade_in
        } else {
            self.has_fade(i - 1)
        };
        let right = if i + 1 == self.clips.len() {
            self.clips[i].fade_out
        } else {
            self.has_fade(i)
        };
        left && right
    }

    /// The fade from black at the very start of the video: the first clip's own (REQ-083).
    pub fn start_fade(&self) -> bool {
        self.clips.first().is_some_and(|c| c.fade_in)
    }

    /// The fade to black at the very end of the video: the last clip's own.
    pub fn end_fade(&self) -> bool {
        self.clips.last().is_some_and(|c| c.fade_out)
    }

    /// Sets the fade from black of the first clip (its own fade-in).
    pub fn set_start_fade(&mut self, on: bool) -> Result<(), EditError> {
        self.clips
            .first_mut()
            .map(|c| c.fade_in = on)
            .ok_or(EditError::EmptyTimeline)
    }

    /// Sets the fade to black of the last clip (its own fade-out).
    pub fn set_end_fade(&mut self, on: bool) -> Result<(), EditError> {
        self.clips
            .last_mut()
            .map(|c| c.fade_out = on)
            .ok_or(EditError::EmptyTimeline)
    }

    /// Sets or removes the fade in of the first clip and the fade out of the last clip
    /// (the whole-video Fade IN/OUT, REQ-147).
    pub fn set_edge_fades(&mut self, on: bool) -> Result<(), EditError> {
        if self.clips.is_empty() {
            return Err(EditError::EmptyTimeline);
        }
        if let Some(c) = self.clips.first_mut() {
            c.fade_in = on;
        }
        if let Some(c) = self.clips.last_mut() {
            c.fade_out = on;
        }
        Ok(())
    }

    /// True when any fade (boundary, start or end) is set.
    pub fn has_any_fade(&self) -> bool {
        !self.fades.is_empty() || self.start_fade() || self.end_fade()
    }

    /// Removes every fade (boundaries, start and end flags of every clip).
    pub fn clear_fades(&mut self) {
        self.fades.clear();
        for c in &mut self.clips {
            c.fade_in = false;
            c.fade_out = false;
        }
    }

    // ---- Apply LUT (1.6.0) ----

    /// The LUT file path of a clip; for the whole video, the first clip's (REQ-147).
    pub fn lut_of(&self, t: FrameTarget) -> Option<&str> {
        let id = match t {
            FrameTarget::Whole => self.clips.first()?.id,
            FrameTarget::Clip(id) => id,
        };
        self.clip_luts
            .iter()
            .find(|l| l.clip == id)
            .map(|l| l.path.as_str())
    }

    /// Sets (`Some`) or removes (`None`) the LUT of a clip, or of every clip for the whole
    /// video; an unknown clip is refused.
    pub fn set_lut(&mut self, t: FrameTarget, path: Option<String>) -> Result<(), EditError> {
        match t {
            FrameTarget::Clip(id) => {
                self.get(id).ok_or(EditError::NoSuchClip)?;
                self.put_lut(id, path);
            }
            FrameTarget::Whole => {
                if self.clips.is_empty() {
                    return Err(EditError::EmptyTimeline);
                }
                let ids: Vec<ClipId> = self.clips.iter().map(|c| c.id).collect();
                for id in ids {
                    self.put_lut(id, path.clone());
                }
            }
        }
        Ok(())
    }

    fn put_lut(&mut self, id: ClipId, path: Option<String>) {
        let path = path.filter(|p| !p.is_empty());
        self.clip_luts.retain(|l| l.clip != id);
        if let Some(path) = path {
            self.clip_luts.push(ClipLut { clip: id, path });
            self.clip_luts.sort_by_key(|l| l.clip);
        }
    }

    /// True when any Apply LUT exists (the export is then a re-encode, REQ-136).
    pub fn any_lut(&self) -> bool {
        !self.clip_luts.is_empty()
    }

    // ---- Change aspect, Scale and Move (1.5.0) ----

    /// The keyframes of a clip, if it has any.
    pub fn frames_of(&self, id: ClipId) -> Option<&ClipFrames> {
        self.clip_frames.iter().find(|f| f.clip == id)
    }

    /// The (scale, move) keys of a clip, empty when it has none.
    fn keys_of(&self, id: ClipId) -> (&[Key<Scale>], &[Key<Pos>]) {
        match self.frames_of(id) {
            Some(f) => (&f.scale, &f.moved),
            None => (&[], &[]),
        }
    }

    /// Stores the keyframes of a clip (replacing its entry; an empty entry is dropped).
    pub fn put_frames(&mut self, f: ClipFrames) {
        self.clip_frames.retain(|x| x.clip != f.clip);
        if !f.scale.is_empty() || !f.moved.is_empty() {
            self.clip_frames.push(f);
            self.clip_frames.sort_by_key(|x| x.clip);
        }
    }

    /// The clip whose keys the whole-video popup shows (REQ-148): the first clip that has
    /// a Scale or a Move.
    fn whole_ref(&self) -> Option<&Clip> {
        self.clips.iter().find(|c| {
            let (s, m) = self.keys_of(c.id);
            !s.is_empty() || !m.is_empty()
        })
    }

    /// The Scale keys of a clip; for the whole video, those of the first clip that has
    /// keys (source time of that clip).
    pub fn scale_keys(&self, t: FrameTarget) -> &[Key<Scale>] {
        match t {
            FrameTarget::Whole => self.whole_ref().map_or(&[], |c| self.keys_of(c.id).0),
            FrameTarget::Clip(id) => self.keys_of(id).0,
        }
    }

    pub fn move_keys(&self, t: FrameTarget) -> &[Key<Pos>] {
        match t {
            FrameTarget::Whole => self.whole_ref().map_or(&[], |c| self.keys_of(c.id).1),
            FrameTarget::Clip(id) => self.keys_of(id).1,
        }
    }

    fn check_target(&self, t: FrameTarget) -> Result<(), EditError> {
        match t {
            FrameTarget::Whole if self.clips.is_empty() => Err(EditError::EmptyTimeline),
            FrameTarget::Clip(id) if self.get(id).is_none() => Err(EditError::NoSuchClip),
            _ => Ok(()),
        }
    }

    /// Runs `f` on the keys of every clip that has some of this kind, at the same clip
    /// time as the reference clip's `at` (REQ-148). A clip that ends before that time is
    /// left alone. The result is the one of the first clip handled; the other clips' keys
    /// that cannot take the change (a key at that time, the last key) stay as they are.
    fn whole_edit<T: Copy>(
        &mut self,
        pick: fn(&mut ClipFrames) -> &mut Vec<Key<T>>,
        at: Micros,
        mut f: impl FnMut(&mut Vec<Key<T>>, Micros) -> Result<(), keyframes::KeyError>,
    ) -> Result<(), EditError> {
        self.check_target(FrameTarget::Whole)?;
        let ref_in = self.whole_ref().map_or(Micros::ZERO, |c| c.src_in);
        let ct = (at - ref_in).max(Micros::ZERO);
        let mut first: Option<Result<(), keyframes::KeyError>> = None;
        for i in 0..self.clips.len() {
            let c = self.clips[i];
            let Some(mut e) = self.frames_of(c.id).cloned() else {
                continue;
            };
            let at_i = c.src_in + ct;
            if pick(&mut e).is_empty() || at_i > c.src_out {
                continue;
            }
            let r = f(pick(&mut e), at_i);
            first.get_or_insert(r);
            if r.is_ok() {
                self.put_frames(e);
            }
        }
        first.unwrap_or(Ok(())).map_err(EditError::Key)
    }

    /// Runs `f` on the scale keys of `t` (an entry of a clip is made when missing and
    /// dropped again when it ends up empty).
    fn with_scale<R>(
        &mut self,
        t: FrameTarget,
        f: impl FnOnce(&mut Vec<Key<Scale>>) -> R,
    ) -> Result<R, EditError> {
        self.check_target(t)?;
        let FrameTarget::Clip(id) = t else {
            return Err(EditError::NoSuchClip);
        };
        let mut e = self.frames_of(id).cloned().unwrap_or(ClipFrames {
            clip: id,
            scale: vec![],
            moved: vec![],
        });
        let r = f(&mut e.scale);
        self.put_frames(e);
        Ok(r)
    }

    fn with_move<R>(
        &mut self,
        t: FrameTarget,
        f: impl FnOnce(&mut Vec<Key<Pos>>) -> R,
    ) -> Result<R, EditError> {
        self.check_target(t)?;
        let FrameTarget::Clip(id) = t else {
            return Err(EditError::NoSuchClip);
        };
        let mut e = self.frames_of(id).cloned().unwrap_or(ClipFrames {
            clip: id,
            scale: vec![],
            moved: vec![],
        });
        let r = f(&mut e.moved);
        self.put_frames(e);
        Ok(r)
    }

    /// Where a new Scale or Move of a clip starts: its first source instant.
    pub fn frame_start(&self, t: FrameTarget) -> Micros {
        match t {
            FrameTarget::Whole => self.whole_ref().map_or(Micros::ZERO, |c| c.src_in),
            FrameTarget::Clip(id) => self.get(id).map_or(Micros::ZERO, |c| c.src_in),
        }
    }

    /// The time of a key of `t` at timeline position `at`: the clip's source time; for the
    /// whole video, the same clip time in the reference clip (REQ-148), so `at` is the clip
    /// time of the clip under it.
    pub fn key_time(&self, t: FrameTarget, at: Micros) -> Option<Micros> {
        match t {
            FrameTarget::Whole => {
                let (i, start) = self.locate(at).or_else(|| {
                    let last = self.clips.len().checked_sub(1)?;
                    Some((last, self.start_of(last)))
                })?;
                let c = &self.clips[i];
                let local = (at - start).clamp(Micros::ZERO, c.len());
                Some(self.frame_start(FrameTarget::Whole) + local)
            }
            FrameTarget::Clip(id) => {
                let i = self.index_of(id)?;
                let c = &self.clips[i];
                Some(c.src_in + (at - self.start_of(i)).clamp(Micros::ZERO, c.len()))
            }
        }
    }

    /// Adds Scale (100 %, one keyframe at the start) to a clip, or to every clip that has
    /// none for the whole video (one copy per clip, REQ-148); false when nothing was added.
    pub fn add_scale(&mut self, t: FrameTarget) -> Result<bool, EditError> {
        self.add_normal(
            t,
            |c| c.scale.is_empty(),
            |c, at| {
                c.scale.push(Key {
                    t: at,
                    v: Scale::NORMAL,
                })
            },
        )
    }

    /// Adds Move (centred, one keyframe at the start); false when it is there.
    pub fn add_move(&mut self, t: FrameTarget) -> Result<bool, EditError> {
        self.add_normal(
            t,
            |c| c.moved.is_empty(),
            |c, at| {
                c.moved.push(Key {
                    t: at,
                    v: frame::CENTRE,
                })
            },
        )
    }

    fn add_normal(
        &mut self,
        t: FrameTarget,
        lacks: impl Fn(&ClipFrames) -> bool,
        push: impl Fn(&mut ClipFrames, Micros),
    ) -> Result<bool, EditError> {
        self.check_target(t)?;
        let ids: Vec<(ClipId, Micros)> = match t {
            FrameTarget::Whole => self.clips.iter().map(|c| (c.id, c.src_in)).collect(),
            FrameTarget::Clip(id) => vec![(id, self.frame_start(t))],
        };
        let mut any = false;
        for (id, at) in ids {
            let mut e = self.frames_of(id).cloned().unwrap_or(ClipFrames {
                clip: id,
                scale: vec![],
                moved: vec![],
            });
            if lacks(&e) {
                push(&mut e, at);
                self.put_frames(e);
                any = true;
            }
        }
        Ok(any)
    }

    pub fn remove_scale(&mut self, t: FrameTarget) -> Result<(), EditError> {
        if self.scale_keys(t).is_empty() && !self.any_keys(t, true) {
            return Err(EditError::NoSuchEffect);
        }
        self.remove_kind(t, true)
    }

    pub fn remove_move(&mut self, t: FrameTarget) -> Result<(), EditError> {
        if self.move_keys(t).is_empty() && !self.any_keys(t, false) {
            return Err(EditError::NoSuchEffect);
        }
        self.remove_kind(t, false)
    }

    /// True when some clip of the target has keys of this kind.
    fn any_keys(&self, t: FrameTarget, scale: bool) -> bool {
        let has = |id: ClipId| {
            let (s, m) = self.keys_of(id);
            if scale { !s.is_empty() } else { !m.is_empty() }
        };
        match t {
            FrameTarget::Whole => self.clips.iter().any(|c| has(c.id)),
            FrameTarget::Clip(id) => has(id),
        }
    }

    fn remove_kind(&mut self, t: FrameTarget, scale: bool) -> Result<(), EditError> {
        self.check_target(t)?;
        let ids: Vec<ClipId> = match t {
            FrameTarget::Whole => self.clips.iter().map(|c| c.id).collect(),
            FrameTarget::Clip(id) => vec![id],
        };
        for id in ids {
            if let Some(mut e) = self.frames_of(id).cloned() {
                if scale {
                    e.scale.clear();
                } else {
                    e.moved.clear();
                }
                self.put_frames(e);
            }
        }
        Ok(())
    }

    /// Sets the Scale key at `at` (adds it when there is none); limits are applied. For the
    /// whole video the key is set at the same clip time in every copy.
    pub fn set_scale_key(
        &mut self,
        t: FrameTarget,
        at: Micros,
        mut v: Scale,
    ) -> Result<(), EditError> {
        v.clamp();
        if self.scale_keys(t).is_empty() {
            return Err(EditError::NoSuchEffect);
        }
        match t {
            FrameTarget::Whole => {
                self.whole_edit(|e| &mut e.scale, at, |k, t| keyframes::set(k, t, v))
            }
            FrameTarget::Clip(_) => self
                .with_scale(t, |k| keyframes::set(k, at, v))?
                .map_err(EditError::Key),
        }
    }

    pub fn set_move_key(&mut self, t: FrameTarget, at: Micros, v: Pos) -> Result<(), EditError> {
        let v = Pos {
            x: v.x.min(crate::subtitles::POS_MAX),
            y: v.y.min(crate::subtitles::POS_MAX),
        };
        if self.move_keys(t).is_empty() {
            return Err(EditError::NoSuchEffect);
        }
        match t {
            FrameTarget::Whole => {
                self.whole_edit(|e| &mut e.moved, at, |k, t| keyframes::set(k, t, v))
            }
            FrameTarget::Clip(_) => self
                .with_move(t, |k| keyframes::set(k, at, v))?
                .map_err(EditError::Key),
        }
    }

    /// Adds a Scale key (never replaces one).
    pub fn add_scale_key(
        &mut self,
        t: FrameTarget,
        at: Micros,
        mut v: Scale,
    ) -> Result<(), EditError> {
        v.clamp();
        if self.scale_keys(t).is_empty() {
            return Err(EditError::NoSuchEffect);
        }
        match t {
            FrameTarget::Whole => {
                self.whole_edit(|e| &mut e.scale, at, |k, t| keyframes::add(k, t, v))
            }
            FrameTarget::Clip(_) => self
                .with_scale(t, |k| keyframes::add(k, at, v))?
                .map_err(EditError::Key),
        }
    }

    pub fn add_move_key(&mut self, t: FrameTarget, at: Micros, v: Pos) -> Result<(), EditError> {
        if self.move_keys(t).is_empty() {
            return Err(EditError::NoSuchEffect);
        }
        match t {
            FrameTarget::Whole => {
                self.whole_edit(|e| &mut e.moved, at, |k, t| keyframes::add(k, t, v))
            }
            FrameTarget::Clip(_) => self
                .with_move(t, |k| keyframes::add(k, at, v))?
                .map_err(EditError::Key),
        }
    }

    /// Removes the Scale key at `at`; the last key stays.
    pub fn remove_scale_key(&mut self, t: FrameTarget, at: Micros) -> Result<(), EditError> {
        match t {
            FrameTarget::Whole => self.whole_edit(|e| &mut e.scale, at, keyframes::remove),
            FrameTarget::Clip(_) => self
                .with_scale(t, |k| keyframes::remove(k, at))?
                .map_err(EditError::Key),
        }
    }

    pub fn remove_move_key(&mut self, t: FrameTarget, at: Micros) -> Result<(), EditError> {
        match t {
            FrameTarget::Whole => self.whole_edit(|e| &mut e.moved, at, keyframes::remove),
            FrameTarget::Clip(_) => self
                .with_move(t, |k| keyframes::remove(k, at))?
                .map_err(EditError::Key),
        }
    }

    /// Sets or removes Change aspect.
    pub fn set_frame_aspect(&mut self, a: Option<FrameAspect>) -> Result<(), EditError> {
        if self.clips.is_empty() {
            return Err(EditError::EmptyTimeline);
        }
        self.frame_aspect = a;
        Ok(())
    }

    /// True when Change aspect, Scale or Move changes the picture (REQ-131: such a project
    /// is always re-encoded).
    pub fn has_frame_effect(&self) -> bool {
        self.frame_aspect.is_some()
            || self.clips.iter().any(|c| {
                let (s, m) = self.keys_of(c.id);
                !s.is_empty() || !m.is_empty()
            })
    }

    /// The Scale and Move keys that act on the clip at `index`: its own copy only, since a
    /// clip has at most one Scale and one Move (REQ-130, REQ-131).
    pub fn frame_stack(&self, index: usize) -> Stack {
        let mut st = Stack::default();
        let Some(c) = self.clips.get(index) else {
            return st;
        };
        let (s, m) = self.keys_of(c.id);
        if !s.is_empty() {
            st.scale.push(Track {
                keys: s.to_vec(),
                offset: c.src_in,
            });
        }
        if !m.is_empty() {
            st.moved.push(Track {
                keys: m.to_vec(),
                offset: c.src_in,
            });
        }
        st
    }

    /// Sets a clip's sound level (0–100 %, clamped) and mute.
    pub fn set_clip_volume(
        &mut self,
        id: ClipId,
        volume: u8,
        muted: bool,
    ) -> Result<(), EditError> {
        let i = self.index_of(id).ok_or(EditError::NoSuchClip)?;
        self.clips[i].volume = volume.min(FULL_VOLUME);
        self.clips[i].muted = muted;
        Ok(())
    }

    /// Switches Clean audio on or off for the clips `ids` (REQ-114).
    pub fn set_clean_audio(&mut self, ids: &[ClipId], on: bool) -> Result<(), EditError> {
        if ids.is_empty() {
            return Err(EditError::NothingSelected);
        }
        if ids.iter().any(|i| self.get(*i).is_none()) {
            return Err(EditError::NoSuchClip);
        }
        for c in self.clips.iter_mut().filter(|c| ids.contains(&c.id)) {
            c.clean_audio = on;
        }
        Ok(())
    }

    /// True when any clip has Clean audio.
    pub fn any_clean_audio(&self) -> bool {
        self.clips.iter().any(|c| c.clean_audio)
    }

    /// Boundary closest to `t` (index and time), if any.
    pub fn nearest_boundary(&self, t: Micros) -> Option<(usize, Micros)> {
        let mut start = Micros::ZERO;
        let mut best: Option<(usize, Micros)> = None;
        // Every clip but the last ends on a boundary.
        let inner = self.clips.len().saturating_sub(1);
        for (i, clip) in self.clips[..inner].iter().enumerate() {
            start = start + clip.len();
            let better = best.is_none_or(|(_, bt)| (start - t).0.abs() < (bt - t).0.abs());
            if better {
                best = Some((i, start));
            }
        }
        best
    }
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::media::{MediaFormat, MediaItem};
    use std::path::PathBuf;

    pub fn media(id: u64, secs: i64, video: bool) -> MediaItem {
        MediaItem {
            id: MediaId(id),
            path: PathBuf::from(format!("/m/{id}.mp4")),
            name: format!("{id}.mp4"),
            duration: Micros(secs * 1_000_000),
            format: MediaFormat {
                container: "mp4".into(),
                vcodec: video.then(|| "h264".into()),
                acodec: Some("aac".into()),
                width: 1280,
                height: 720,
                fps: crate::time::Fps::new(30, 1),
                ..Default::default()
            },
            missing: false,
            status: Default::default(),
            proxy: Default::default(),
        }
    }

    const F: Micros = Micros(33_333);

    fn s(n: i64) -> Micros {
        Micros(n * 1_000_000)
    }

    fn track() -> Timeline {
        let mut t = Timeline::default();
        t.append(&media(1, 4, true)).unwrap();
        t.append(&media(2, 6, true)).unwrap();
        t
    }

    // covers: REQ-005
    #[test]
    fn append_places_clips_end_to_end() {
        let t = track();
        assert_eq!(t.clips.len(), 2);
        assert_eq!(t.duration(), s(10));
        assert_eq!(t.start_of(1), s(4));
        assert_eq!(t.locate(s(4)), Some((1, s(4))));
        assert_eq!(t.locate(s(10)), None);
        // contiguous: each clip starts where the previous ends
        let mut end = Micros::ZERO;
        for (i, c) in t.clips.iter().enumerate() {
            assert_eq!(t.start_of(i), end);
            end = end + c.len();
        }
    }

    // covers: REQ-002
    #[test]
    fn audio_only_cannot_be_placed() {
        let mut t = Timeline::default();
        let e = t.append(&media(3, 2, false)).unwrap_err();
        assert_eq!(e, EditError::NoVideo("3.mp4".into()));
        let mut m = media(4, 2, true);
        m.missing = true;
        assert!(matches!(t.append(&m), Err(EditError::MissingMedia(_))));
        let mut z = media(5, 0, true);
        z.duration = Micros::ZERO;
        assert_eq!(t.append(&z), Err(EditError::InvalidRange));
    }

    // covers: REQ-006
    #[test]
    fn split_keeps_total_length() {
        let mut t = track();
        let right = t.split(s(5), F).unwrap();
        assert_eq!(t.clips.len(), 3);
        assert_eq!(t.duration(), s(10));
        assert_eq!(t.clips[1].src_out, s(1));
        assert_eq!(t.clips[2].id, right);
        assert_eq!(t.clips[2].src_in, s(1));
        assert_eq!(t.split(s(4), F), Err(EditError::NotInsideClip));
        assert_eq!(t.split(s(99), F), Err(EditError::NotInsideClip));
        assert_eq!(t.split(Micros(10), F), Err(EditError::NotInsideClip));
    }

    // covers: REQ-007
    #[test]
    fn cut_and_paste_ripple() {
        let mut t = track();
        let first = t.clips[0].id;
        let c = t.remove(first).unwrap();
        assert_eq!(t.duration(), s(6));
        assert_eq!(t.remove(first), Err(EditError::NoSuchClip));
        // paste at the end
        let id = t.insert_at(&c, s(6), F).unwrap();
        assert_eq!(t.clips.last().unwrap().id, id);
        // paste at a boundary (start)
        t.insert_at(&c, Micros::ZERO, F).unwrap();
        assert_eq!(t.clips[0].media, MediaId(1));
        assert_eq!(t.duration(), s(14));
        // paste in the middle of a clip splits it and ripples right
        let before = t.duration();
        let id = t.insert_at(&c, s(6), F).unwrap();
        assert_eq!(t.duration(), before + c.len());
        let i = t.index_of(id).unwrap();
        assert_eq!(t.start_of(i), s(6));
        // too close to an edge: snaps to the nearest boundary
        let n = t.clips.len();
        t.insert_at(&c, Micros(10), F).unwrap();
        assert_eq!(t.clips.len(), n + 1);
        assert_eq!(t.clips[0].media, MediaId(1));
        let end_of_first = t.start_of(1);
        t.insert_at(&c, end_of_first - Micros(10), F).unwrap();
        let empty = Clip::new(ClipId(0), MediaId(1), s(1), s(1));
        assert_eq!(t.insert_at(&empty, s(0), F), Err(EditError::InvalidRange));
    }

    // covers: REQ-008
    #[test]
    fn merge_only_contiguous_same_source() {
        let mut t = track();
        let a = t.clips[0].id;
        assert!(!t.can_merge(a));
        assert_eq!(t.merge(a), Err(EditError::NotMergeable));
        let right = t.split(s(2), F).unwrap();
        assert!(t.can_merge(a));
        assert!(!t.can_merge(right)); // next clip is another file
        t.toggle_fade(0).unwrap();
        t.toggle_fade(1).unwrap();
        t.merge(a).unwrap();
        assert_eq!(t.clips.len(), 2);
        assert_eq!(t.clips[0].src_out, s(4));
        assert!(t.has_fade(0)); // fade after the merged clip survives
        assert!(!t.can_merge(ClipId(999)));
        // not contiguous in source: trim makes a gap
        let r = t.split(s(2), F).unwrap();
        t.trim(r, s(3), s(4), s(4), F).unwrap();
        assert!(!t.can_merge(a));
    }

    // covers: REQ-009
    #[test]
    fn trim_is_clamped_to_source() {
        let mut t = track();
        let a = t.clips[0].id;
        t.trim(a, Micros(-5), s(99), s(4), F).unwrap();
        assert_eq!((t.clips[0].src_in, t.clips[0].src_out), (s(0), s(4)));
        t.trim(a, s(1), s(3), s(4), F).unwrap();
        assert_eq!(t.clips[0].len(), s(2));
        assert_eq!(t.duration(), s(8));
        assert_eq!(t.trim(a, s(3), s(3), s(4), F), Err(EditError::InvalidRange));
        assert_eq!(
            t.trim(ClipId(77), s(0), s(1), s(4), F),
            Err(EditError::NoSuchClip)
        );
    }

    // covers: REQ-010
    #[test]
    fn move_reorders_with_ripple() {
        let mut t = track();
        let a = t.clips[0].id;
        t.toggle_fade(0).unwrap();
        t.move_to(a, 5).unwrap();
        assert_eq!(t.clips[1].id, a);
        assert_eq!(t.start_of(1), s(6));
        assert!(t.fades.is_empty()); // the boundary no longer exists
        assert_eq!(t.move_to(ClipId(42), 0), Err(EditError::NoSuchClip));
    }

    // covers: REQ-011
    #[test]
    fn fade_toggle_and_lengths() {
        let mut t = track();
        assert!(t.toggle_fade(0).unwrap());
        assert!(t.has_fade(0));
        assert_eq!(t.fades_of(0), (Micros::ZERO, MAX_FADE));
        assert_eq!(t.fades_of(1), (MAX_FADE, Micros::ZERO));
        assert_eq!(t.fades_of(9), (Micros::ZERO, Micros::ZERO));
        assert_eq!(t.duration(), s(10)); // clips are not shortened
        assert!(!t.toggle_fade(0).unwrap());
        assert!(!t.has_fade(0));
        assert_eq!(t.toggle_fade(1), Err(EditError::NoSuchBoundary));
        let short = Clip::new(ClipId(1), MediaId(1), s(0), Micros(600_000));
        assert_eq!(short.fade_len(), Micros(300_000));
        // split keeps the fade on the right half's boundary
        t.toggle_fade(0).unwrap();
        let right = t.split(s(2), F).unwrap();
        assert!(t.fades.contains(&(right, t.clips[2].id)));
    }

    #[test]
    fn nearest_boundary() {
        let t = track();
        assert_eq!(t.nearest_boundary(s(1)), Some((0, s(4))));
        let mut t3 = track();
        t3.append(&media(3, 2, true)).unwrap();
        assert_eq!(t3.nearest_boundary(s(9)), Some((1, s(10))));
        assert_eq!(Timeline::default().nearest_boundary(s(1)), None);
    }

    fn three() -> Timeline {
        let mut t = track();
        t.append(&media(3, 5, true)).unwrap();
        t
    }

    // covers: REQ-083, REQ-011
    #[test]
    fn fade_on_a_clip_sets_both_of_its_edges() {
        // (a) the middle clip: its two boundaries, nothing at the start or end
        let mut t = three();
        let ids: Vec<ClipId> = t.clips.iter().map(|c| c.id).collect();
        t.set_clip_fades(ids[1], true).unwrap();
        assert!(t.has_fade(0) && t.has_fade(1));
        assert!(!t.start_fade() && !t.end_fade());
        assert!(t.clip_has_fades(ids[1]));
        assert!(!t.clip_has_fades(ids[0]));
        // removing it from the clip removes both edges
        t.set_clip_fades(ids[1], false).unwrap();
        assert!(!t.has_any_fade());
        // (b) the first clip: fade from black at the start + its boundary
        t.set_clip_fades(ids[0], true).unwrap();
        assert!(t.start_fade() && t.has_fade(0) && !t.has_fade(1) && !t.end_fade());
        assert_eq!(t.fades_of(0), (MAX_FADE, MAX_FADE));
        // the last clip: its boundary + fade to black at the end
        t.set_clip_fades(ids[2], true).unwrap();
        assert!(t.end_fade() && t.has_fade(1));
        assert_eq!(t.fades_of(2), (MAX_FADE, MAX_FADE));
        assert_eq!(
            t.set_clip_fades(ClipId(99), true),
            Err(EditError::NoSuchClip)
        );
        assert!(!t.clip_has_fades(ClipId(99)));
        t.clear_fades();
        assert!(!t.has_any_fade());
    }

    // covers: REQ-083, REQ-011
    #[test]
    fn whole_video_fades_stay_at_the_video_edges() {
        let mut t = three();
        assert_eq!(
            Timeline::default().set_edge_fades(true),
            Err(EditError::EmptyTimeline)
        );
        t.set_edge_fades(true).unwrap();
        assert!(t.fades.is_empty(), "no boundary fades");
        assert_eq!(t.fades_of(0), (MAX_FADE, Micros::ZERO));
        assert_eq!(t.fades_of(2), (Micros::ZERO, MAX_FADE));
        // deleting the first clip removes its start fade (REQ-083): it belongs to the clip
        let first = t.clips[0].id;
        t.remove(first).unwrap();
        assert_eq!(t.fades_of(0).0, Micros::ZERO);
        assert_eq!(t.fades_of(1), (Micros::ZERO, MAX_FADE));
        // moving the first clip to the end: its start fade moves with it (a boundary fade
        // is not there, so nothing shows at the start)
        let mut u = three();
        u.set_edge_fades(true).unwrap();
        let first = u.clips[0].id;
        u.move_to(first, 9).unwrap();
        assert_eq!(u.fades_of(0).0, Micros::ZERO);
        assert_eq!(u.fades_of(2), (Micros::ZERO, Micros::ZERO));
        assert!(u.clips[2].fade_in && !u.start_fade());
        // a clip shorter than 1 s fades over half its length
        let mut short = Timeline::default();
        short.append(&media(1, 4, true)).unwrap();
        let id = short.clips[0].id;
        short.trim(id, s(0), Micros(600_000), s(4), F).unwrap();
        short.set_edge_fades(true).unwrap();
        assert_eq!(short.fades_of(0), (Micros(300_000), Micros(300_000)));
        t.set_edge_fades(false).unwrap();
        assert!(!t.start_fade() && !t.end_fade());
    }

    // covers: REQ-084, REQ-020, REQ-008
    #[test]
    fn clip_volume_follows_split_copy_and_reorder_and_blocks_merge() {
        let mut t = track();
        let a = t.clips[0].id;
        assert!(!t.clips[0].has_volume());
        t.set_clip_volume(a, 250, false).unwrap();
        assert_eq!(t.clips[0].volume, 100, "never above 100%");
        t.set_clip_volume(a, 50, true).unwrap();
        assert!(t.clips[0].has_volume());
        assert_eq!(
            t.set_clip_volume(ClipId(77), 1, false),
            Err(EditError::NoSuchClip)
        );
        // (c) split keeps the level on both halves; the halves can be merged back
        let right = t.split(s(2), F).unwrap();
        assert_eq!((t.clips[0].volume, t.clips[0].muted), (50, true));
        let r = *t.get(right).unwrap();
        assert_eq!((r.volume, r.muted), (50, true));
        assert!(t.can_merge(a));
        // a copy keeps it, so does a move
        let id = t.insert_at(&r, t.duration(), F).unwrap();
        assert_eq!(t.get(id).unwrap().volume, 50);
        t.move_to(id, 0).unwrap();
        assert_eq!(t.clips[0].volume, 50);
        // different volumes: no merge, with the reason
        t.set_clip_volume(right, 80, true).unwrap();
        assert!(!t.can_merge(a));
        assert_eq!(t.merge_block_reason(a), Some(DIFFERENT_VOLUMES));
        assert_eq!(t.merge(a), Err(EditError::NotMergeable));
        assert_eq!(
            t.merge_block_reason(right),
            None,
            "not contiguous: other reason"
        );
        t.set_clip_volume(right, 50, true).unwrap();
        t.merge(a).unwrap();
    }

    // covers: REQ-135
    #[test]
    fn lut_rules_set_remove_split_merge_and_remove_clip() {
        let mut t = track();
        let a = t.clips[0].id;
        assert!(!t.any_lut());
        assert_eq!(
            t.set_lut(FrameTarget::Clip(ClipId(99)), Some("x.cube".into())),
            Err(EditError::NoSuchClip)
        );
        t.set_lut(FrameTarget::Clip(a), Some("/l/a.cube".into()))
            .unwrap();
        t.set_lut(FrameTarget::Whole, Some("/l/w.cube".into()))
            .unwrap();
        assert!(t.any_lut());
        // the whole-video LUT is a copy on each clip and replaces the clip's own (REQ-147)
        assert_eq!(t.lut_of(FrameTarget::Clip(a)), Some("/l/w.cube"));
        assert_eq!(t.lut_of(FrameTarget::Whole), Some("/l/w.cube"));
        t.set_lut(FrameTarget::Clip(a), Some("/l/a.cube".into()))
            .unwrap();
        // split: both halves have it, and can merge back
        let right = t.split(s(2), F).unwrap();
        assert_eq!(t.lut_of(FrameTarget::Clip(right)), Some("/l/a.cube"));
        assert!(t.can_merge(a));
        // different files block the merge, with the reason
        t.set_lut(FrameTarget::Clip(right), Some("/l/b.cube".into()))
            .unwrap();
        assert_eq!(t.merge_block_reason(a), Some(DIFFERENT_LUTS));
        t.set_lut(FrameTarget::Clip(right), None).unwrap();
        assert_eq!(t.merge_block_reason(a), Some(DIFFERENT_LUTS));
        t.set_lut(FrameTarget::Whole, None).unwrap();
        t.merge(a).unwrap();
        assert!(t.clip_luts.is_empty(), "empty entries are removed");
        // removing a clip drops its entry; an empty path removes
        t.set_lut(FrameTarget::Clip(a), Some("/l/a.cube".into()))
            .unwrap();
        t.set_lut(FrameTarget::Clip(a), Some(String::new()))
            .unwrap();
        assert!(t.clip_luts.is_empty());
        t.set_lut(FrameTarget::Clip(a), Some("/l/a.cube".into()))
            .unwrap();
        t.remove(a).unwrap();
        assert!(t.clip_luts.is_empty());
        t.set_lut(FrameTarget::Whole, None).unwrap();
        assert!(!t.any_lut());
    }

    // covers: REQ-114
    #[test]
    fn clean_audio_follows_split_copy_and_move_and_blocks_merge() {
        let mut t = track();
        let a = t.clips[0].id;
        assert!(!t.any_clean_audio());
        assert_eq!(
            t.set_clean_audio(&[], true),
            Err(EditError::NothingSelected)
        );
        assert_eq!(
            t.set_clean_audio(&[ClipId(77)], true),
            Err(EditError::NoSuchClip)
        );
        t.set_clean_audio(&[a], true).unwrap();
        assert!(t.any_clean_audio());
        let right = t.split(s(2), F).unwrap();
        assert!(t.clips[0].clean_audio && t.get(right).unwrap().clean_audio);
        assert!(t.can_merge(a));
        let r = *t.get(right).unwrap();
        let id = t.insert_at(&r, t.duration(), F).unwrap();
        assert!(t.get(id).unwrap().clean_audio);
        t.move_to(id, 0).unwrap();
        assert!(t.clips[0].clean_audio);
        t.set_clean_audio(&[right], false).unwrap();
        assert!(!t.can_merge(a));
        assert_eq!(t.merge_block_reason(a), Some(DIFFERENT_CLEAN_AUDIO));
        assert_eq!(t.merge(a), Err(EditError::NotMergeable));
        t.set_clean_audio(&[right], true).unwrap();
        t.merge(a).unwrap();
        // old files have it off
        let c: Clip = serde_json::from_str(r#"{"id":1,"media":2,"src_in":0,"src_out":5}"#).unwrap();
        assert!(!c.clean_audio);
    }

    // covers: REQ-094
    #[test]
    fn clips_and_timelines_of_1_1_read_with_defaults() {
        let c: Clip = serde_json::from_str(r#"{"id":1,"media":2,"src_in":0,"src_out":5}"#).unwrap();
        assert_eq!((c.volume, c.muted), (100, false));
        let t: Timeline =
            serde_json::from_str(r#"{"clips":[],"fades":[],"next_clip_id":0}"#).unwrap();
        assert!(!t.start_fade() && !t.end_fade());
    }

    fn one() -> (Timeline, ClipId) {
        let mut t = Timeline::default();
        let id = t.append(&media(1, 8, true)).unwrap();
        (t, id)
    }

    fn sc(p: u16) -> Scale {
        Scale {
            permille: p,
            dx: 0,
            dy: 0,
        }
    }

    // covers: REQ-129
    // covers: REQ-130
    #[test]
    fn scale_and_move_start_with_one_key_and_a_second_add_does_nothing() {
        let (mut t, id) = one();
        let c = FrameTarget::Clip(id);
        assert!(t.add_scale(c).unwrap());
        assert!(!t.add_scale(c).unwrap());
        assert!(t.add_move(FrameTarget::Whole).unwrap());
        assert_eq!(
            t.scale_keys(c),
            &[Key {
                t: Micros::ZERO,
                v: Scale::NORMAL
            }]
        );
        assert_eq!(t.move_keys(FrameTarget::Whole).len(), 1);
        assert!(t.has_frame_effect());
        t.remove_scale(c).unwrap();
        assert_eq!(t.remove_scale(c), Err(EditError::NoSuchEffect));
        t.remove_move(FrameTarget::Whole).unwrap();
        assert!(t.clip_frames.is_empty(), "empty entries are removed");
        assert_eq!(
            t.add_scale(FrameTarget::Clip(ClipId(99))),
            Err(EditError::NoSuchClip)
        );
        assert_eq!(
            Timeline::default().add_move(FrameTarget::Whole),
            Err(EditError::EmptyTimeline)
        );
    }

    // covers: REQ-147, REQ-148
    #[test]
    fn a_whole_video_scale_is_a_copy_on_each_clip_changed_together_and_alone() {
        let mut t = track(); // clips of 4 s and 6 s
        let (a, b) = (t.clips[0].id, t.clips[1].id);
        let w = FrameTarget::Whole;
        assert!(t.add_scale(w).unwrap());
        assert!(!t.add_scale(w).unwrap(), "no second copy");
        assert_eq!(t.scale_keys(FrameTarget::Clip(a)).len(), 1);
        assert_eq!(t.scale_keys(FrameTarget::Clip(b)).len(), 1);
        // a key at 5 s of clip time reaches only the clip that is long enough
        t.add_scale_key(w, s(5), sc(2000)).unwrap();
        assert_eq!(t.scale_keys(FrameTarget::Clip(a)).len(), 1);
        assert_eq!(t.scale_keys(FrameTarget::Clip(b)).len(), 2);
        // a key at 2 s: both copies; a value change sets it in each
        t.add_scale_key(w, s(2), sc(1500)).unwrap();
        t.set_scale_key(w, s(2), sc(1800)).unwrap();
        for id in [a, b] {
            let k = t.scale_keys(FrameTarget::Clip(id));
            assert!(k.iter().any(|x| x.t == s(2) && x.v.permille == 1800));
        }
        // a clip's own copy changes that clip only; the popup shows the first clip's keys
        t.set_scale_key(FrameTarget::Clip(b), s(2), sc(700))
            .unwrap();
        assert_eq!(t.scale_keys(FrameTarget::Clip(a))[1].v.permille, 1800);
        assert_eq!(t.scale_keys(w), t.scale_keys(FrameTarget::Clip(a)));
        // removing the key at 2 s removes it from each copy; the last key stays
        t.remove_scale_key(w, s(2)).unwrap();
        assert_eq!(t.scale_keys(FrameTarget::Clip(a)).len(), 1);
        assert_eq!(t.scale_keys(FrameTarget::Clip(b)).len(), 2);
        // deleting a clip takes its copy; a clip added later has none
        t.remove(a).unwrap();
        assert!(t.frames_of(a).is_none());
        let c = t.append(&media(9, 3, true)).unwrap();
        assert!(t.frames_of(c).is_none());
        // Remove effect on the whole video: every clip's copy
        t.remove_scale(w).unwrap();
        assert!(t.clip_frames.is_empty());
    }

    // covers: REQ-147
    #[test]
    fn a_whole_video_move_and_lut_are_one_copy_per_clip_and_fades_stay_with_clips() {
        let mut t = track();
        let (a, b) = (t.clips[0].id, t.clips[1].id);
        let w = FrameTarget::Whole;
        // a clip that has a Move keeps its own and gets no second copy
        t.add_move(FrameTarget::Clip(b)).unwrap();
        t.set_move_key(FrameTarget::Clip(b), t.clips[1].src_in, Pos { x: 1, y: 2 })
            .unwrap();
        assert!(t.add_move(w).unwrap());
        assert_eq!(t.move_keys(FrameTarget::Clip(b))[0].v, Pos { x: 1, y: 2 });
        assert_eq!(t.move_keys(FrameTarget::Clip(a))[0].v, frame::CENTRE);
        // the Apply LUT: one copy per clip, later clips have none
        t.set_lut(w, Some("/l/a.cube".into())).unwrap();
        let c = t.append(&media(9, 3, true)).unwrap();
        assert_eq!(t.lut_of(FrameTarget::Clip(a)), Some("/l/a.cube"));
        assert_eq!(t.lut_of(FrameTarget::Clip(c)), None);
        // the whole-video fade sits on the first and the last clip
        t.set_edge_fades(true).unwrap();
        assert!(t.clips[0].fade_in && t.clips[2].fade_out && !t.clips[1].fade_in);
        assert!(!t.clips[0].fade_out && !t.clips[2].fade_in);
        // a split keeps the start fade on the left half and the end fade on the right one
        let right = t.split(s(1), F).unwrap();
        assert!(t.get(a).unwrap().fade_in && !t.get(a).unwrap().fade_out);
        assert!(!t.get(right).unwrap().fade_in);
    }

    // covers: REQ-129
    #[test]
    fn keys_are_added_set_removed_and_clamped() {
        let (mut t, id) = one();
        let c = FrameTarget::Clip(id);
        assert_eq!(
            t.set_scale_key(c, s(1), sc(500)),
            Err(EditError::NoSuchEffect)
        );
        t.add_scale(c).unwrap();
        t.add_scale_key(c, s(4), sc(2000)).unwrap();
        assert_eq!(
            t.add_scale_key(c, s(4), sc(1)),
            Err(EditError::Key(KeyError::SameTime))
        );
        t.set_scale_key(c, s(4), sc(9000)).unwrap();
        assert_eq!(t.scale_keys(c)[1].v.permille, 4000);
        t.set_scale_key(c, s(2), sc(1)).unwrap();
        assert_eq!(t.scale_keys(c)[1].v.permille, 100);
        t.remove_scale_key(c, s(2)).unwrap();
        t.remove_scale_key(c, s(4)).unwrap();
        assert_eq!(
            t.remove_scale_key(c, Micros::ZERO),
            Err(EditError::Key(KeyError::LastKey))
        );
        t.add_move(c).unwrap();
        t.add_move_key(c, s(1), Pos { x: 60000, y: 1 }).unwrap();
        t.set_move_key(c, s(1), Pos { x: 65000, y: 2 }).unwrap();
        assert_eq!(t.move_keys(c)[1].v, Pos { x: 10000, y: 2 });
        t.remove_move_key(c, s(1)).unwrap();
        t.remove_move(c).unwrap();
        assert_eq!(
            t.add_move_key(c, s(1), frame::CENTRE),
            Err(EditError::NoSuchEffect)
        );
        assert_eq!(t.key_time(c, s(3)), Some(s(3)));
        assert_eq!(t.key_time(FrameTarget::Whole, s(3)), Some(s(3)));
        assert_eq!(t.key_time(FrameTarget::Clip(ClipId(9)), s(3)), None);
    }

    // covers: REQ-129
    #[test]
    fn split_gives_both_halves_the_path_and_trim_keeps_keys() {
        let (mut t, id) = one();
        let c = FrameTarget::Clip(id);
        t.add_scale(c).unwrap();
        t.add_scale_key(c, s(8), sc(2000)).unwrap();
        let right = t.split(s(4), F).unwrap();
        assert_eq!(t.scale_keys(c), t.scale_keys(FrameTarget::Clip(right)));
        // the value at the new edge is the one the path had there
        let st = t.frame_stack(1);
        let p = st.at(Micros::ZERO);
        assert!((p.factor - 1.5).abs() < 1e-9);
        t.trim(right, s(6), s(8), s(8), F).unwrap();
        assert_eq!(t.scale_keys(FrameTarget::Clip(right)).len(), 2);
        t.remove(right).unwrap();
        assert!(t.frames_of(right).is_none());
    }

    // covers: REQ-129
    #[test]
    fn merge_needs_equal_keys() {
        let (mut t, id) = one();
        let right = t.split(s(4), F).unwrap();
        assert!(t.can_merge(id));
        t.add_scale(FrameTarget::Clip(right)).unwrap();
        assert!(!t.can_merge(id));
        assert_eq!(t.merge_block_reason(id), Some(DIFFERENT_FRAMES));
        t.add_scale(FrameTarget::Clip(id)).unwrap();
        assert!(!t.can_merge(id));
        t.add_scale_key(FrameTarget::Clip(id), s(4), Scale::NORMAL)
            .unwrap();
        t.add_scale_key(FrameTarget::Clip(right), Micros::ZERO, Scale::NORMAL)
            .unwrap();
        t.merge(id).unwrap();
        assert!(t.frames_of(right).is_none());
        assert_eq!(t.scale_keys(FrameTarget::Clip(id)).len(), 2);
    }

    // covers: REQ-124
    // covers: REQ-131
    #[test]
    fn change_aspect_is_one_effect_of_the_whole_video() {
        let (mut t, _) = one();
        assert!(!t.has_frame_effect());
        t.set_frame_aspect(Some(FrameAspect::default())).unwrap();
        assert!(t.has_frame_effect());
        t.set_frame_aspect(None).unwrap();
        assert!(!t.has_frame_effect());
        assert_eq!(
            Timeline::default().set_frame_aspect(None),
            Err(EditError::EmptyTimeline)
        );
    }

    // covers: REQ-131
    #[test]
    fn the_stack_of_a_clip_has_the_whole_video_first() {
        let (mut t, id) = one();
        let right = t.split(s(4), F).unwrap();
        t.add_scale(FrameTarget::Whole).unwrap();
        t.add_move(FrameTarget::Clip(right)).unwrap();
        let st = t.frame_stack(1);
        assert_eq!(st.scale.len(), 1);
        assert_eq!(st.scale[0].offset, s(4));
        assert_eq!(st.moved[0].offset, s(4));
        assert!(t.frame_stack(0).moved.is_empty());
        assert!(t.frame_stack(7).is_empty());
        let _ = id;
    }

    // covers: REQ-132
    #[test]
    fn frame_fields_round_trip_and_old_timelines_have_none() {
        let (mut t, id) = one();
        t.add_scale(FrameTarget::Clip(id)).unwrap();
        t.add_move(FrameTarget::Whole).unwrap();
        t.set_frame_aspect(Some(FrameAspect::default())).unwrap();
        let j = serde_json::to_string(&t).unwrap();
        assert_eq!(serde_json::from_str::<Timeline>(&j).unwrap(), t);
        let old = Timeline::default();
        let j = serde_json::to_string(&old).unwrap();
        assert!(!j.contains("frame_aspect") && !j.contains("clip_frames"));
    }
}
